//correct
package slidingWindow;

import java.util.HashSet;

public class LongestSubStrWithAllUnique {
	
	public static int longestSubStrAllUniChar(String str ) {
		
		int l=0,r=0;
		int maxLength=Integer.MIN_VALUE;
		HashSet<Character> hashSet = new HashSet<>();
		while(r<str.length()) {
			
			if(!hashSet.contains(str.charAt(r))) {
				hashSet.add(str.charAt(r));
				//window is expanding and so need to calc maxLength
				maxLength=Math.max(maxLength, r-l+1);
			}
			else {
				//element present
				maxLength=Math.max(maxLength, r-l);
				while(hashSet.contains(str.charAt(r))) {
					//calculate l position
					hashSet.remove(str.charAt(l));
					l++;
					//window is squeezing.. no need to calc maxLength
					
				}
				hashSet.add(str.charAt(r));
			}
			
			r++;
		}
		return maxLength;
	}
	
	
	public static void main(String[] args) {
		//String s="pwabcwkew";
		String s="wpwabcwefw";
		System.out.println(longestSubStrAllUniChar(s));
	}

}

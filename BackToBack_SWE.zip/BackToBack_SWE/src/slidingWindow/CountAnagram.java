package slidingWindow;
//correct
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map.Entry;

public class CountAnagram {


	public static boolean isAnagram(String i, String p) {

		HashMap<Character, Integer> i1=new HashMap<>();
		HashMap<Character, Integer> p1=new HashMap<>();

		//process input

		for(int x=0; x<i.length();x++) {

			i1.put(i.charAt(x),(i1.getOrDefault(i.charAt(x), 0))+1);
		}

		for(int y=0; y<p.length();y++) {

			p1.put(p.charAt(y),(p1.getOrDefault(p.charAt(y), 0))+1);
		}
		
		if(i1.size()!=p1.size()) {
			return false;
		}
		
		for(Entry<Character, Integer> q: i1.entrySet()) {
			
			char key =q.getKey();
			int val  = q.getValue();
			
			if(!p1.containsKey(key)) {
				return false;
			}
			if(p1.get(key)!=val) {
				return false;
			}
			
		}
		return true;

	}

	public static int countAnagram(String input, String pattern) {
		
		
		int k = pattern.length();
		int right=0,left=0, count=0;
		String si="";
		List<String> anagramList =new ArrayList<>();
		
		while(right<=input.length()) {
			
			si=input.substring(left, right);
			if(right-left==k) {
				//size reached
				if(isAnagram(si, pattern)) {
					count++;
					anagramList.add(si);
				}
				
				left++;
				si="";
			}
			
			right++;
			
		}
		
		for(String s: anagramList) {
			System.out.println(s);
			
		}
		
	return count;
}
	
	
	public static void main(String[] args) {
		
		/*String input="aaba";
		String pattern="aasa";*/
		/*String input="aabaabaa";
		String pattern="aaba";*/
		String input="cbaebabacd";
		String pattern="abc";
		
		  
		
		System.out.println(isAnagram(input, pattern));
		System.out.println(countAnagram(input, pattern));
		

	}

}

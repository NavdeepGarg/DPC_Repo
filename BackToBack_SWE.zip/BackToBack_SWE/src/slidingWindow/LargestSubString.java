package slidingWindow;
//correct
import java.util.HashMap;

//Longest Substring Without Repeating Characters

public class LargestSubString {


	public int lengthOfLongestSubstring(String s) {

		if(s==null|| s.isEmpty()) {
			return 0;
		}
		
		if(s.length()==1) {
			return 1;
		}
		HashMap<Character, Integer> map = new HashMap<>();
		
		int left=0, right=0;
		int windowSize=0;
		for( right =0 ; right<s.length();right++) {
			//System.out.println(s.charAt(right));
			if(map.containsKey(s.charAt(right))) {				
				
				windowSize =Math.max(windowSize, right-left);
				left=Math.max(map.get(s.charAt(right))+1,left);
			 
				map.put(s.charAt(right), right);
			}
			else {
			
				map.put(s.charAt(right), right);
		
				
			}
			
			
		}
		windowSize= Math.max(windowSize, right-left);
		return windowSize;
		
	}


	public static void main(String[] args) {
	// String s = "abcabcbb";
	 //String s = "bbbb";
	 String s = "abba";
//	String s = "au";
//		 String s = "pwwkew";
	 LargestSubString o =new LargestSubString();
	 System.out.println(o.lengthOfLongestSubstring(s));
		
	}

}

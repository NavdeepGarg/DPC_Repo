//correct
package slidingWindow;

import java.util.LinkedList;
import java.util.Queue;
 
public class FirstNegativeNumber {
	
	
	
	public static void pringFirstNegative(int[] arr, int k ) {

		int left =0 ; 
		int right=0;
		 
		Queue<Integer> list = new LinkedList<>();
		 while(right<arr.length) {
			 
			 
			 if(arr[right]<0) {
				 list.add(arr[right]);
				 
			 }
			 if(right-left+1==k) {
				 if(list.size()==0) {
					 System.out.println(0);
				 }
				 else {
					 if(arr[left]==list.peek()) {
						 System.out.println(list.poll());
					 }
					 else {
						 System.out.println(list.peek());
					 }
				 }
				 left++;
			 }
			 
			 right++;
		 }

		
		
	}

	public static void main(String[] args) {

		int arr[]= {12,-1,-7,8,-15,30,16,28};

		int left =0 ; int k =3;
		int right=k+left-1;

		boolean firstNegative=false;
		  
		for( left=0;left<=arr.length-k;left++) {
			
			right=k+left-1;
			int i = left;
			while(i<=right) {
				if(arr[i]<0) {
					System.out.println(arr[i]);
					firstNegative=true;
					break;
					
				}
				i++;
			}
			
			if(!firstNegative) {
				System.out.println(0);
			}
			
			firstNegative=false;
		}
		System.out.println("-----------");
		
		pringFirstNegative(arr, 3);
		
		
	}

}

package slidingWindow;

public class MaxsubArraySumSizeK {

	
	public static void main(String[] args) {
		int arr[]= {2,5,1,8,2,9,1};
		
		int left =0 ; int k =3;
		int right=k+left-1;
		
		int maxSum=Integer.MIN_VALUE;
		int currentSum=0;
		for(int i =left; i<=right;i++) {
			currentSum+=arr[i];
			
		}
		maxSum=Math.max(currentSum, maxSum);
		right++;
		for(;right<arr.length;right++,left++) {
			
			currentSum-=arr[left];
			currentSum+=arr[right];
			
			maxSum=Math.max(currentSum, maxSum);
			
		}
		
		System.out.println("max Sum "+maxSum);
	} 
	
	
	
	
}

//correct
package slidingWindow;

import java.util.HashMap;

public class LongestSubStrKUniqueChar {

	public static int calWindowSize(String str, int k ) {

		int l=0,r=0;
		int maxLength= Integer.MIN_VALUE;
		HashMap<Character, Integer> map = new HashMap<>();

		while(r<str.length()) {

			if(map.size()<k) {
				map.put(str.charAt(r), map.getOrDefault(str.charAt(r), 0)+1);


			}

			else if(map.size()==k) {

				if(map.containsKey(str.charAt(r))) {
					map.put(str.charAt(r), map.getOrDefault(str.charAt(r), 0)+1);
					maxLength = Math.max(maxLength,r-l+1);
				}
				else {
					//new element

					while(true) {

						char temp = str.charAt(l);
						 
							map.put(str.charAt(l), map.get(str.charAt(l))-1);
							if(map.get(temp)==null || map.get(temp)==0) {
								map.remove(temp);
								map.put(str.charAt(r), 1);
								l++;
								break;
							}
							l++;
						

					}
					
				}



			}

			r++;


		}
		return maxLength;
	}


	public static void main(String[] args) {

		String str="aabacbebebe";
		int k =3;
		System.out.println(calWindowSize(str, k));

	}

}

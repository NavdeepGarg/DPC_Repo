package slidingWindow;

import java.util.ArrayList;
import java.util.Deque;
import java.util.LinkedList;
import java.util.List;

public class MaxSubArrayElementSizeK {
	
	 
	public static List<Integer> storeMaxElementInSubArray(int[] arr, int k){
		
		
		int l=0,r=0;
		
		Deque<Integer> queue
        = new LinkedList<>();
		List<Integer> output = new ArrayList<Integer>();
		while(r<arr.length) {
			
			
			
			if(r-l+1==k) {
				
				if(arr[r]>queue.peek()) {
					queue.poll();
					queue.offerFirst(arr[r]);
					output.add(arr[r]);
					l++;
				}else {
				queue.offerLast(arr[r]);
				output.add(queue.peek());
				l++;
				}
				
				
				
			}
			if(queue.size()==0) {
				queue.add(arr[r]);
			}else {
				
				if(arr[r]>queue.peek()) {
					queue.poll();
					queue.offerFirst(arr[r]);
				}else
				queue.offerLast(arr[r]);
			}
			r++;
		}
		
		for(Integer i : output) {
			System.out.println(i);
		}
		
		return output;
	}
	
	public static void main(String[] args) {
		
		int arr[]= {1,3,-1,-3,5,3,6,7};
		int k =3;
		storeMaxElementInSubArray(arr, k);
		
	}

}

package dailyCodingProblem;

//subarray length with equal no. of 0s and 1s

public class SubArrayUniform {
	
	
	public int calculateSubArrayLength(int[] arr) {
		
		int countOne=0;
		int countZero=0;
		int start = 0,end=0;
		int maxLength=Integer.MIN_VALUE;
		for(int i =start ; i < arr.length-1;i++) {
			 countOne=0;
			 countZero=0;
			 end=i;
			if(arr[i]==0) 
				countZero++;
			else
				countOne++;
			
			for(int j=i+1;j<arr.length;j++ ) {
				if(arr[j]==0) 
					countZero++;
				else
					countOne++;
				if(countOne==countZero) {
					end=j;
				}
				
				
			}
			if(end-i+1 >maxLength) {
				maxLength=end-i+1;
			}
		}
		
		return maxLength;
	}
	
	public static void main(String[] args) {
		
		int arr[]= {1,0,1,0,1};
		//int arr[]= {1,1,1,0};
		SubArrayUniform obj = new SubArrayUniform();
		System.out.println(obj.calculateSubArrayLength(arr));
		
	}

}

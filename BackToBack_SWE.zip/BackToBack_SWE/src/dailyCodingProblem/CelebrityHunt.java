//correct
package dailyCodingProblem;



public class CelebrityHunt {
	
	public int celebIdPresent(int[][] gathering) {
		
		int start=0;
		int end =gathering.length-1;
		
		while(start<end) {
			
			if(gathering[start][end]==1) {
				//that means start knows ends therefore start is not a celeb
				start++;
			}else {
				//that means ends is not known by start therefore end is not a celeb
				end--;
			}
		}
		
		for (int i = 0; i < gathering.length; i++) 
	    { 
	        if ( (i != start) && (gathering[start][i] == 1 || gathering[i][start] == 0)) 
	            return -1; 
	    } 
	  
	    return start;
		
	}
	
	public static void main(String[] args) {
		
	}

}

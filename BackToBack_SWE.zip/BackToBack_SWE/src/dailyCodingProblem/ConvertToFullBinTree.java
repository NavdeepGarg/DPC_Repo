//correct
package dailyCodingProblem;

import java.util.LinkedList;
import java.util.Queue;

public class ConvertToFullBinTree {
	
	
	public TreeNode convertFullBinTree(TreeNode root) {
		
		if(root==null) {
			return null;
		}
		
		if(root.getLeft()==null && root.getRight()==null) {
			return root;
		}
		 
		TreeNode leftnode = root.getLeft();
		TreeNode rightnode = root.getRight();
		
		convertFullBinTree(leftnode,root,'L');
		convertFullBinTree(rightnode,root,'R');
		return root;
		
	}
	
	private void convertFullBinTree(TreeNode node, TreeNode origin, char c) {
		 
		if(node==null) {
			return;
		}
		if(node.getLeft()==null && node.getRight()==null) {
			return;
		}
		
		if(node.getLeft()!=null && node.getRight()==null) {
			if(c=='L') {
				origin.setLeft(node.getLeft());
				convertFullBinTree(node.getLeft(), origin, 'L');	
			}
			
			else {
				origin.setRight(node.getLeft());
				convertFullBinTree(node.getLeft(), origin, 'R');
				
			}
			 
		}
		
		
		if(node.getLeft()==null && node.getRight()!=null) {
			if(c=='L') {
				origin.setLeft(node.getRight());
				convertFullBinTree(node.getRight(), origin, 'L');	
			}
			
			else {
				origin.setRight(node.getRight());
				convertFullBinTree(node.getRight(), origin, 'R');
				
			}
			 
		}
		
	}

	
	public void bfsTreeTraversal(TreeNode root) {
		 
		Queue<TreeNode> q = new LinkedList<>();
		q.add(root);
		
		while(!q.isEmpty()) {
			
			TreeNode temp = q.poll();
			System.out.println(temp.getValue());
			
			if(temp.getLeft()!=null)q.add(temp.getLeft());
			if(temp.getRight()!=null)q.add(temp.getRight());
			
		}
		
		
	}
	public static void main(String[] args) {
		
		TreeNode root = new TreeNode(0);
		TreeNode one = new TreeNode(1);
		TreeNode two  = new TreeNode(2);
		TreeNode three = new TreeNode(3);
		TreeNode five = new TreeNode(5);
		TreeNode four = new TreeNode(4);
		TreeNode six = new TreeNode(6);
		TreeNode seven = new TreeNode(7);
		root.setLeft(one);root.setRight(two);
		one.setLeft(three);one.setRight(null);
		three.setLeft(null);three.setRight(five);
		two.setLeft(null); two.setRight(four);
		four.setLeft(six);four.setRight(seven);
		six.setLeft(null);six.setRight(null);seven.setLeft(null);seven.setRight(null);
		
		ConvertToFullBinTree obj  = new ConvertToFullBinTree();
		obj.convertFullBinTree(root);
		obj.bfsTreeTraversal(root);
		
		
		
	}

}

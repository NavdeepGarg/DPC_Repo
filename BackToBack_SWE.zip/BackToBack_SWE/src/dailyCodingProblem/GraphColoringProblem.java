package dailyCodingProblem;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

class Vertex {
	
	private int value;
	private int vertexColor;
	private List<Integer> adjList;
	public Vertex(int value) {
		super();
		this.value = value;
		this.adjList=new ArrayList<Integer>();
	}
	public int getValue() {
		return value;
	}
	public void setValue(int value) {
		this.value = value;
	}
	public int getVertexColor() {
		return vertexColor;
	}
	public void setVertexColor(int vertexColor) {
		this.vertexColor = vertexColor;
	}
	public List<Integer> getAdjList() {
		return adjList;
	}
	public void setAdjList(List<Integer> adjList) {
		this.adjList = adjList;
	} 
	
	
	
}


public class GraphColoringProblem {


	public void printGraph(Graph g) {
		
		List<Vertex> vertexList = g.getVertexList();
		for(Vertex v: vertexList) {
			
			System.out.println("vertex "+v.getValue());
			for(Integer adj: v.getAdjList()) {
				System.out.print( adj+"\t");
			}
			System.out.println("");
		}
		
	}

	//k different colors
	public void colorGraph(Graph g , int[] color) {
		
		List<Vertex> vertexList = g.getVertexList();
		Map<Integer,Vertex> result = new HashMap<>();
		for(Vertex v: vertexList) {
			
			List<Integer>adjList =  v.getAdjList();
			Set<Integer> alreadyAssignedColors = new HashSet<>();
			for(int i : adjList) {
				
				if(result.containsKey(i)) {
					Vertex x = result.get(i);
					alreadyAssignedColors.add(x.getVertexColor());
				}
				 
			}
			
			//Set<Integer> allowedToAssign = new HashSet<>();
			List<Integer> allowedToAssign = new LinkedList<Integer>();
			for( int temp : color) {
				if(alreadyAssignedColors.contains(temp)) {
					continue;
				}
				
				allowedToAssign.add(temp);
			}
			
			if(allowedToAssign.size()==0) {
				//return as nothing if boolean function is the required in return call 
				System.out.println("void");
			}
			else {
				v.setVertexColor(allowedToAssign.get(0));
				result.put(v.getValue(), v);
			}
		}
		
		for(Entry<Integer, Vertex> e :result.entrySet()) {
			System.out.println("Vertex "+e.getKey()+"--Color "+e.getValue().getVertexColor());
		}
		
	}
	
	
	public static void main(String[] args) {
		
	
	//creation of graph
	Vertex v0= new Vertex(0);
	v0.getAdjList().add(1);v0.getAdjList().add(4);v0.getAdjList().add(5);
	Vertex v1 = new Vertex(1);
	v1.getAdjList().add(0);v1.getAdjList().add(4);v1.getAdjList().add(3);
	Vertex v2 = new Vertex(2);
	v2.getAdjList().add(3);v2.getAdjList().add(4);
	Vertex v3 = new Vertex(3);
	v3.getAdjList().add(2);v3.getAdjList().add(1);
	Vertex v4 = new Vertex(4);
	v4.getAdjList().add(0);v4.getAdjList().add(2);v4.getAdjList().add(5);
	Vertex v5 = new Vertex(5);
	v5.getAdjList().add(0);v5.getAdjList().add(4);
	
	Graph g = new Graph();
	List<Vertex> vertexList=g.getVertexList();
	vertexList.add(v0);vertexList.add(v1);vertexList.add(v2);vertexList.add(v3);vertexList.add(v4);vertexList.add(v5);
	g.setVertexList(vertexList);
	
	int k =3;
	int[]color = new int[k];
	 for(int i =0; i < k ;i++) {
		 color[i]=i;
	 }
	
	GraphColoringProblem obj = new GraphColoringProblem();
	//obj.printGraph(g);
	obj.colorGraph(g, color);
	
	
	}
}


class Graph{
	 
	List<Vertex> vertexList;

	public List<Vertex> getVertexList() {
		return vertexList;
	}

	public void setVertexList(List<Vertex> vertexList) {
		this.vertexList = vertexList;
	}

	public Graph() {
		super();
		this.vertexList = new ArrayList<>();
		// TODO Auto-generated constructor stub
	}

	 	
}

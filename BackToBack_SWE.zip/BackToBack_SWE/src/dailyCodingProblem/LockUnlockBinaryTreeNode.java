//Pending, google asked

package dailyCodingProblem;

class TreeNodeLock{
	
	private int value;
	private TreeNodeLock left;
	private TreeNodeLock right;
	private TreeNodeLock parentNode;
	private boolean nodeisLock;
	
	
	
 
	public boolean isNodeisLock() {
		return nodeisLock;
	}
	public void setNodeisLock(boolean nodeisLock) {
		this.nodeisLock = nodeisLock;
	}
	public int getValue() {
		return value;
	}
	public void setValue(int value) {
		this.value = value;
	}
	public TreeNodeLock getLeft() {
		return left;
	}
	public void setLeft(TreeNodeLock left) {
		this.left = left;
	}
	public TreeNodeLock getRight() {
		return right;
	}
	public void setRight(TreeNodeLock right) {
		this.right = right;
	}
	public TreeNodeLock getParentNode() {
		return parentNode;
	}
	public void setParentNode(TreeNodeLock parentNode) {
		this.parentNode = parentNode;
	}
	public TreeNodeLock(int value) {
		super();
		this.value = value;
	}
	
	
	
}

public class LockUnlockBinaryTreeNode {

	public void lock (TreeNodeLock node) {
		
	}
	
	
	
	public static void main(String[] args) {
		
	}
}

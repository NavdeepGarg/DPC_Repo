package dailyCodingProblem;

import java.util.Arrays;

public class ScalerQuestion {
	
	
	private int findMaxIndex(int[] a) {
		int max = a[0];
		int index = 0;

		for (int i = 0; i < a.length; i++) 
		{
			if (max < a[i]) 
			{
				max = a[i];
				index = i;
			}
		}
		
		return index;
		
	}
	
	private int findMinIndex(int[] a) {
		int min = a[0];
		int index = 0;

		for (int i = 0; i < a.length; i++) 
		{
			if (min > a[i]) 
			{
				min = a[i];
				index = i;
			}
		}
		
		return index;
		
	}
	
	private int calculateAbsDiffernce(int[] a) {
		
		int minIndex= this.findMinIndex(a);
		int maxIndex= this.findMaxIndex(a);
		
		int absDiff = Math.abs(a[maxIndex]-a[minIndex]);
		return absDiff;
		
	}
	
	private int calculatOverAllSum(int [] a) {
		int overAllSum=0;
		for(int i : a) {
			overAllSum+=i;
			
		}
		return overAllSum;
	}
	
	private int minimizeDifference(int [] a,  int b) {
		
		
		int maxValue= a[this.findMaxIndex(a)];
		int minValue= a[this.findMinIndex(a)];
		
		int absDiff = Math.abs(maxValue-minValue);
		int overAllsum=0;
		for(int i : a) {
			overAllsum+=i;
			
		}
		int tempDiff=0;
		boolean minElementIndexUsed=false;
		boolean overAllSumDecreases=false;
		int tempOverAllSum=0;
		
		int operationCount=1;
		//for( operationCount=1 ; operationCount<= b; operationCount++) {
		while(b>0) {
			
			if(minElementIndexUsed) {
				//check for max value
				int firstMaxIndex = this.findMaxIndex(a);
				--a[firstMaxIndex];
				tempOverAllSum=calculatOverAllSum(a);
				if(tempOverAllSum <overAllsum) {
					overAllsum=tempOverAllSum;
					b--;
					tempDiff = calculateAbsDiffernce(a);
					if(tempDiff<absDiff) {
						absDiff=tempDiff;
					}
					minElementIndexUsed=false;
					System.out.println(Arrays.toString(a));
					
				}
				else {
					++a[firstMaxIndex];
					minElementIndexUsed=false;
				}
				
			}
			else {
				//check for min value
				
				int firstMinIndex = this.findMinIndex(a);
				++a[firstMinIndex];
				tempOverAllSum=calculatOverAllSum(a);
				if(tempOverAllSum <overAllsum) {
					overAllsum=tempOverAllSum;
					b--;
					tempDiff = calculateAbsDiffernce(a);
					if(tempDiff<absDiff) {
						absDiff=tempDiff;
					}
					minElementIndexUsed=true;
					System.out.println(Arrays.toString(a));
				}
				else {
					--a[firstMinIndex];
					minElementIndexUsed=true;
				}
				
			}
			
			
			
		}
		
		return absDiff; 
	
		
		
		
	}
	
	public static void main(String[] args) {
		
		//int a[]= {2,3,6,8,9};
		int a[]= {2,8,3,7,8,7,9};
	//	int a[]= {4,6,3,1,4};
		//int a[]= {1,1,7};
		//int b =5;
		//int b =3;
		int b =9;
		ScalerQuestion obj =new ScalerQuestion();
		int x = obj.minimizeDifference(a, b);
		System.out.println(x);
		
	}

}


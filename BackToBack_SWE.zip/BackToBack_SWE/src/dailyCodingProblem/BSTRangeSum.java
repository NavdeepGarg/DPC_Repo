//correct
package dailyCodingProblem;

import java.util.ArrayList;
import java.util.List;

class TreeNode{
	
	private int value ;
	private TreeNode left;
	private TreeNode right;
	public int getValue() {
		return value;
	}
	public void setValue(int value) {
		this.value = value;
	}
	public TreeNode getLeft() {
		return left;
	}
	public void setLeft(TreeNode left) {
		this.left = left;
	}
	public TreeNode getRight() {
		return right;
	}
	public void setRight(TreeNode right) {
		this.right = right;
	}
	public TreeNode(int value) {
		super();
		this.value = value;
	}
	
	
}

public class BSTRangeSum {
	
	
	public int calculateSuminRange(TreeNode root, int start, int end) {
		
		//perform inorder traversal
		
		List<Integer> list = new ArrayList<Integer>();
		inorderTraversal(root, list);
		int sum=0;
		
		
		for(int temp : list) {
			
			if(temp>=start && temp <=end) {
				sum+=temp;
				
			}
		}
		return sum;
	}
	
	private void inorderTraversal(TreeNode root, List<Integer> list) {
		
		if(root==null) {
			return;
		}
		
		inorderTraversal(root.getLeft(), list);
		list.add(root.getValue());
		inorderTraversal(root.getRight(), list);
		return;
	}
	
	public static void main(String[] args) {
		TreeNode root = new TreeNode(5);
		TreeNode rootLeft = new TreeNode(3);
		TreeNode rootRight= new TreeNode(8);
		TreeNode rootLeftLeft = new TreeNode(2);
		TreeNode rootLeftRight= new TreeNode(4);
		TreeNode rootRightLeft = new TreeNode(6);
		TreeNode rootRightRight = new TreeNode(10);
		
		root.setLeft(rootLeft);root.setRight(rootRight);
		rootLeft.setLeft(rootLeftLeft);rootLeft.setRight(rootLeftRight);
		rootRight.setLeft(rootRightLeft);rootRight.setRight(rootRightRight);
		
		BSTRangeSum obj = new BSTRangeSum();
		System.out.println(obj.calculateSuminRange(root, 4, 9));
		
		
		
	}

}

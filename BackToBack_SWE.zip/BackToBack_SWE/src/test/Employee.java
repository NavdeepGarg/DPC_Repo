package test;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;


class SalaryComparator implements Comparator<Employee>{

	@Override
	public int compare(Employee o1, Employee o2) {
		if(o1.getEmpSalary()>o2.getEmpSalary()) {
			return 1;
		}
		if(o1.getEmpSalary()==o2.getEmpSalary()) {
			return 0;
		}
		if(o1.getEmpSalary()<o2.getEmpSalary()) {
			return -1;
		}
		//return 0;
		return 0;
	}
	
	
}
 
public class Employee {
	
	
	private static int maxDesg=0;
	private static int minDesg=1;
	private  static int maxSalary=1001;
	private  static int minSalary=100;
	
	
	private int employeeID;
	private String employeeName;
	private long empSalary;
	private int desgination;
	
	
	
	public long getEmpSalary() {
		return empSalary;
	}


	public void setEmpSalary(long empSalary) {
		this.empSalary = empSalary;
	}
	
	
	public Employee() {
		super();
		
	}
	
	
	public Employee(int employeeID, String employeeName, int desgination) {
		super();
		this.employeeID = employeeID;
		this.employeeName = employeeName;
		this.desgination = desgination;
	}


	public int getEmployeeID() {
		return employeeID;
	}
	public void setEmployeeID(int employeeID) {
		this.employeeID = employeeID;
	}
	public String getEmployeeName() {
		return employeeName;
	}
	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}
	public int getDesgination() {
		return desgination;
	}
	public void setDesgination(int desgination) {
		this.desgination = desgination;
	}
	
	
	
	public static void assignSalary(Employee e) {
		
		int curDesg= e.getDesgination();
		System.out.println("maxDesg "+Employee.maxDesg);
		int diff = Employee.maxDesg-curDesg;
		int curSalary = Employee.maxSalary-diff*200;
		if(curSalary<Employee.minSalary) {
			curSalary=Employee.minSalary;
		}
		
		e.setEmpSalary(curSalary);
		
		
	}
	
	//HIGHER DESG=100 , LOWER DESG=1
	private static void addEmployee(List<Employee> emplist, Employee e1) {
	 
		
		//client info seek 
		int currDesg = e1.getDesgination();
		if(currDesg >Employee.maxDesg) {
			System.out.println("Changing desg");
			Employee.maxDesg=currDesg;
		}
		emplist.add(e1);
	}
	
	public static void main(String[] args) {
		Employee e1 = new Employee(1,"ABC",1);
		Employee e2 = new Employee(2,"DEF",2);
		Employee e3 = new Employee(3,"IJK",3);
		Employee e4 = new Employee(4,"XYZ",3);
		Employee e5 = new Employee(5,"XYZ",4);
		Employee e6 = new Employee(5,"XYZ",6);
		Employee e7 = new Employee(5,"XYZ",5);
		//MAX IS 1000 , NEXT IS 200 LESS
		//MIN =100
	
		
		
		 List<Employee> emplist= new ArrayList<>();
		 	addEmployee(emplist,e1);addEmployee(emplist,e5);addEmployee(emplist,e6);
		 	assignSalary(e1);assignSalary(e5);assignSalary(e6);
		 	emplist.sort(SalaryComparator<Employee>());
		 	
		 	System.out.println(e1.getEmpSalary()+","+ e6.getEmpSalary()+","+e5.getEmpSalary());
		 	
		/*
		assignSalary(e1);assignSalary(e2);assignSalary(e3);assignSalary(e4);assignSalary(e6);assignSalary(e7);assignSalary(e5);
		System.out.println(e1.getEmpSalary()+", "+e2.getEmpSalary()+", "+e3.getEmpSalary()+", "+e4.getEmpSalary()+","+e5.getEmpSalary()+","+e6.getEmpSalary()+","+e7.getEmpSalary());
		*/
		
	}



	

}

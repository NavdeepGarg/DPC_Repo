package test;

public class PolyMorphParent {
	
	private String parentName;

	public String getParentName() {
		return parentName;
	}

	public void setParentName(String parentName) {
		this.parentName = parentName;
	}
	
	public void parentMethod() {
		System.out.println("ParentMethod");
	}

	public static void main(String[] args) {
		PolyMorphParent c = new PolyMorphParent();
		String s =c.parentName;
	}
}

package test;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public class ArrayRotation {
	
	public static void main(String[] args) {
		
		Integer[] arr= {1,2,3,4};
		//neagtive means right rotation
	 Collections.rotate(Arrays.asList(arr), -1);
	 List<Integer> o = Arrays.asList(arr);
	 System.out.println(o);
		
	}

}

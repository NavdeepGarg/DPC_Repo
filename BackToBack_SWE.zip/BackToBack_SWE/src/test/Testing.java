package test;

import java.net.InetAddress;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.UnknownHostException;
import java.util.Vector;

public class Testing {
	
	


	public static void main(String[] args) throws MalformedURLException, UnknownHostException {
		
		
		String str = "abcd";
		str.trim();
		str.toUpperCase();
		str.substring(3, 4);
		System.out.println(str);
		
		String arr[]= {"A"};
		int a =1;
		int b=0;
		 
/*		TreeSet<Integer> tree = new TreeSet<>();
		tree.add(null);
		tree.add(2);*/
		
		
		URL url = new URL("https://www.ushr.com/welcome");
		System.out.println(url.getPort());
		
		InetAddress addr = InetAddress.getByName("127.0.0.1");
		
		System.out.println(addr.getHostName());
		Vector obj =new Vector(4,1);
		obj.addElement(new Integer(3));
		System.out.println(obj.capacity());
		
		System.out.println(1<<0);
		System.out.println(1<<1);
	}

}

 
package test;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

class Alca{ 
	public static void main(String[] args) throws IOException{ 
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in)); 
		String[]in=br.readLine().split(" "); 
		int[]ar=new int[8]; 
		int sum=0; 
		for(int i=0;i<8;i++){ 
			ar[i]=Integer.parseInt(in[i]); 
			sum+=ar[i]; 
		} 
		int n=Integer.parseInt(br.readLine()); 
		boolean[][]pairs=new boolean[8][8]; 
		for(int i=0;i<n;i++){ 
			in=br.readLine().split(" "); 
			int x=Integer.parseInt(in[0])-1; 
			int y=Integer.parseInt(in[1])-1; 
			pairs[x][y]=pairs[y][x]=true; 
		} 
		int maxScore=0; 
		for(int mask=0;mask<256;mask++){ 
// we will need to unset some bits so taking m as mask 
			int m=mask; 
			int score=0; 
			for(int i=0;i<8;i++){ 
				int x=1<<i; 
				if((m&x)!=0){ 
					for(int j=0;j<8;j++){ 
// if i and j have fight and j-th friend is going in this combination 
						if(pairs[i][j] && (m&(1<<j))!=0) 
// then unset that bit 
							m=m^(1<<j); 
					} 
				} 
			} 
			for(int i=0;i<8;i++){ 
				int x=1<<i; 
				if((m&x)!=0) 
					score+=ar[i]; 
			} 
			maxScore=Math.max(maxScore,score); 
		} 
		System.out.println(maxScore); 
	} 
}
package test;

class TaskEvenOdd implements Runnable {
    private int max;
    private Printer print;
    private boolean isEvenNumber;
  
    public TaskEvenOdd(Printer print, int i, boolean b) {
	 this.print=	 print;
	 this.max=i;
	 this.isEvenNumber=b;
	}

	@Override
    public void run() {
        int number = isEvenNumber ? 2 : 1;
        while (number <= max) {
            if (isEvenNumber) {
                print.printEven(number);
            } else {
                print.printOdd(number);
            }
            number += 2;
        }
    }
}

class Printer {
    private volatile boolean isOdd;
    synchronized void printEven(int number) {
        while (!isOdd) {
            try {
                wait();
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
        }
        System.out.println(Thread.currentThread().getName() + ":" + number);
        isOdd = false;
        notify();
    }
    synchronized void printOdd(int number) {
        while (isOdd) {
            try {
                wait();
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
        }
        System.out.println(Thread.currentThread().getName() + ":" + number);
        isOdd = true;
        notify();
    }
}


public class Solution{
	
	   public static void main(String... args) throws InterruptedException {
		   /*Printer print = new Printer();
	        Thread t1 = new Thread(new TaskEvenOdd(print, 10, false),"Odd");
	        Thread t2 = new Thread(new TaskEvenOdd(print, 10, true),"Even");
	        t1.start();
	        t2.start();*/
		   
		   Thread t1 = new Thread("Sample");
		   t1.start();
		   System.out.println("outside 1 "+Thread.currentThread().getName());
		   synchronized (t1) {
			
			   System.out.println("inside block1 "+Thread.currentThread().getName());
			   
			   t1.wait();
			   System.out.println("inside block2 "+Thread.currentThread().getName());
			   t1.notify();
		}
		   
		   System.out.println("outside 2 "+Thread.currentThread().getName());
	    }
	
}


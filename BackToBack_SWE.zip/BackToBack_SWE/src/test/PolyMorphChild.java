package test;


public class PolyMorphChild extends PolyMorphParent{
	
	private String childName;

	public String getChildName() {
		return childName;
	}

	public void setChildName(String childName) {
		this.childName = childName;
	}
	
	@Override
	public void parentMethod() {
		System.out.println("Parent method in child");
	}
	
	public void childMethod() {
		System.out.println("Child method in child");
	}
	
	
	public static void main(String[] args) {
		
		
		PolyMorphParent c =  new PolyMorphParent();
		//Mixing, then they will only have common behavior
		PolyMorphParent d =  new PolyMorphChild();
		c.parentMethod();
		
		d.setParentName("heello");
		d.parentMethod();
		
		
	System.out.println(d.getParentName() +" , ");
		c=d;
		
		
		
	}

}

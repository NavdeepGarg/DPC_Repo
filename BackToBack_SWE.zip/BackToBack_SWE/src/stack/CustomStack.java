package stack;

public class CustomStack {

	int stackSize;
	int currentSize;
	int[] arr;
	public CustomStack(int maxSize) {

		this.stackSize=maxSize;
		this. currentSize=0;
		this.arr=new int[stackSize];
    }

    public void push(int x) {
    	
    	if(this.currentSize<this.stackSize) {
    			arr[currentSize++]=x;
    	}
    	

    }

    public int pop() {

    	if(currentSize==0) {
    		return -1;
    	}
    	
    	return arr[currentSize--];
    }

    public void increment(int k, int val) {
    	
    	if(k>currentSize) {
    		for(int i =0 ; i <currentSize;i++) {
        		arr[i]+=val;
        	}

    	}
    	else {
    	for(int i =0 ; i <k;i++) {
    		arr[i]+=val;
    	}
    	}
    }
    
    public static void main(String[] args) {
	
    	CustomStack o = new CustomStack(3);
    	o.push(1);;o.push(2);;o.push(3);;
    	o.pop();
    	for(int i = 0 ; i < o.currentSize;i++) {
    		System.out.println(o.arr[i]);
    	}
    	o.increment(1, 100);
    	
    	for(int i = 0 ; i < o.currentSize;i++) {
    		System.out.println(o.arr[i]);
    	}
    
	}
}

package stack;

import java.util.LinkedList;
import java.util.Queue;
import java.util.Stack;

public class RemovalsForValidString {
	
	
	
	public String makeStringValid(String s) {
	       
	      // Create a Stack for storing the Index of opening paranthesis
	      Stack<Integer> stack = new Stack<>();
	       
	      // Using StringBuilder as strings are immutable in Java
	      StringBuilder stringBuilder = new StringBuilder(s);
	       
	      // Iterate through the string
	      for(int i = 1;i<=s.length();i++){
	        // If we encounter openeing paranthesis 
	        // Push it to stack
	        if(s.charAt(i-1) == '(')
	          stack.push(i);
	        
	        //If we encounter closing paranthesis
	        //If stack is not empty we pop the stack
	        //Else we remove closing paranthesis from the string
	        else if(s.charAt(i-1) == ')' && !stack.empty())
	          stack.pop();
	        else if(s.charAt(i-1) ==')' && stack.empty()){//))((
	          stringBuilder.replace(i-1,i, "0");
	        }
	      }
	       
	      // Delete the opening paranthesis that remain in the stack
	      while (!stack.empty()){
	        stringBuilder.deleteCharAt(stack.pop()-1);
	      }
	       
	      // Converts string builder to string and remove the empty spaces
	      return stringBuilder.toString().
	              replace('0',' ').
	              replaceAll("\\s+","");
	    }
	

	public static void main(String[] args) {
		String s = "a)b(c)d(";
		RemovalsForValidString obj = new RemovalsForValidString();
		System.out.println(obj.makeStringValid(s));
	}

}

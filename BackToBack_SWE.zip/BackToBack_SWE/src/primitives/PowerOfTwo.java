package primitives;

//Given a non-negative integer input, return true if input is a power of two. Return false otherwise.

public class PowerOfTwo {

	  public boolean powerOfTwo(int input) {
		  
		  int noOfOnes=0;
		  System.out.println((8 & 1) );
		  if( input ==0 || input ==3){
			    
			    return false;
			  }
		 while(input !=0) {
			 
			 if((input &1) ==1 && noOfOnes <2) {
				 
				 noOfOnes++;
				 
			 }
			 else if(noOfOnes >1) {
				 return false;
			 }
			 input= input >>1;
		 }
		 System.out.println( noOfOnes);
		 return true;
	  }
	
	public static void main(String[] args) {
		
		
		PowerOfTwo obj = new PowerOfTwo();
		System.out.println(obj.powerOfTwo(3));
		
	}
}


//BACK TRACKING PROBLEM , T(4^N) time complexity
package primitives;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class PhoneNumberMnemonics {
	
	HashMap<Character,String> dictionary = new HashMap<>();
	public PhoneNumberMnemonics() {
		// TODO Auto-generated constructor stub
		dictionary.put('2',"abc");
		dictionary.put('3',"def");
		dictionary.put('4',"ghi");
		dictionary.put('5',"jkl");		
		dictionary.put('6',"mno");
		dictionary.put('7',"pqrs");
		dictionary.put('8',"tuw");
		dictionary.put('9',"wxyz");
		
	}
	
	public List<String> letterCombinations(String digits) {
		List<String> output= new ArrayList<String>();
		 if (digits.length() == 0) {
		      return new ArrayList<>();
		    }
		 
		 letterCombinationsUtil(0,digits,output,new StringBuilder());
		 
		 return output;
		
	    
	  }
	
	public void letterCombinationsUtil(int index, String digits, List<String>output,StringBuilder partial){
		
			if(index==digits.length()) {
				output.add(partial.toString());
				return;
			}
			 char c = digits.charAt(index);
			 String temp = this.dictionary.get(c);
			 for(int j =0 ; j < temp.length();j++) {
				 partial.append(temp.charAt(j));
				 letterCombinationsUtil(index+1, digits, output, partial);
				 // tricky catch
				 partial.deleteCharAt(partial.length()-1);
			 }
			
			 
			 
	}
	
	public static void main(String[] args) {
		
		PhoneNumberMnemonics obj = new PhoneNumberMnemonics();
		List<String> output = obj.letterCombinations("43");
		for(String c : output) {
			System.out.println(c); 
			
		}
		
		
	}

}

//not correct, it was actually made on the assumption that subset can only be continous which is wrong.

package primitives;

import java.util.ArrayList;
import java.util.List;

public class SubSetDivisor {
	
	public static void main(String[] args) {
		
		//int[] arr = {3,5,10,20,21};
		//int[] arr = {1,3,6,24};
		int arr[]= {2,3,4,8};
		
		int start =0 , end = 0, i =0; 
		int longestLength=0;
		boolean setStart=false;
		for(int j=1 ; j < arr.length; j++) {
			
			if(arr[i]%arr[j]==0 ||arr[j]%arr[i]==0 ) {
				if(!setStart) {
				start  =i ;
				
				setStart=true;
				}
				
				i++;
			}
			else if(setStart) {
				end = i ;
				longestLength = Math.max(longestLength,end-start+1);
				i++;
				setStart=false;
			}
			else {
				i++;
			}
			
		}
		if(setStart) {
			end = i ;
			longestLength = Math.max(longestLength,end-start+1);
			setStart=false;
		}
		List<Integer> output = new ArrayList<>();
		for(int x = start ; x <=end ;x++) {
			output.add(arr[x]);
			
		}
		
		System.out.println(output.toString());
		System.out.println("ll "+longestLength);
	}

}

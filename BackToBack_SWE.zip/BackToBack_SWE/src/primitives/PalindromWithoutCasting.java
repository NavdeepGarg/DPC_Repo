package primitives;


//You may not cast the number to a string
//This is to check the manipulation done at integer level 
public class PalindromWithoutCasting {
	
	

	 public boolean isPalindrome(int x) {
		 
		 int length = (int) Math.log10(x);
		 System.out.println(length);
		 int mask = (int) Math.pow(10, length);
		 System.out.println(mask);
		 int msd = 0 ; 
		 int lsd = 0; 
		 
		 for( int i = 0; i <= length/2 ; i++) {
			 
			 msd = x/mask;
			 lsd= x%10;
			 System.out.println(x+","+msd +","+lsd); 
			 
			 if(msd!=lsd) {
				 return false;
			 }
			 
			 x=x%mask;
			 x=x/10;
			 mask = mask/100;
			 
		 }
		 
		 return true; 
		 
		 
	 }
	 
	 public static void main(String[] args) {
		
		 int x = 1234321;
		 
		 PalindromWithoutCasting obj = new PalindromWithoutCasting();
		 System.out.println(obj.isPalindrome(x));
		 
	} 
	 

}

package primitives;


//Given an integer as input, write a function that tests if it is a palindrome.

public class Palindrome {

	 public boolean isPalindrome(int x) {
		    
		 

		   if(x<0) {
		     return false;
		   }
		 
		 String s = String.valueOf(x);
		 int middle=0;
		 boolean isPalin= true;
		 
		 if(s.length()==0||s.length()==1){
		   return true;
		 }
		 if(s.length()%2==0) {
			 
			 middle = s.length()/2;
			 for(int i = 0 ; i <middle;i++) {
				 if(s.charAt(middle-1-i)==s.charAt(middle+i)) {
					 continue;
				 }
				 else {
					 isPalin = false;break;
				 }
			 }
			 
		 }
		 else {
			 
			 
			 middle = s.length()/2;
			 for(int i = 1 ; i <=middle;i++) {
				 if(s.charAt(middle-i)==s.charAt(middle+i)) {
					 continue;
				 }
				 else {
					 isPalin = false;break;
				 }
			 }
			 
		 }
	      return isPalin;
	  }
	
	public static void main(String[] args) {
		
		int x = 12212;
		Palindrome obj = new Palindrome();
		System.out.println(obj.isPalindrome(x));
		
	}
}

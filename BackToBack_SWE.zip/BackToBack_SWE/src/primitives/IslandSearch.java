
//WRONG
package primitives;

public class IslandSearch {
	
	
	public int numberOfDistinctIslands(int[][] grid) {
	   
		int [][] visitedGrid = new int [grid.length][grid[0].length];
		int noOfIsland=0;
		
		/*for(int i =0; i < grid.length;i++) {

			for(int j =0 ; j < grid[0].length;j++) {

				System.out.print(visitedGrid[i][j]+",");

			}
			System.out.println("");
		}*/
		for(int i =0; i < grid.length;i++) {
			
			for(int j =0 ; j < grid[0].length;j++) {
				
				if(grid[i][j]==0 || (grid[i][j]==1 && visitedGrid[i][j]==1)) {
					visitedGrid[i][j]=grid[i][j];
					continue;
				}
				
				checkRegion(i,j,grid,visitedGrid);
				
				noOfIsland++;
			}
			
		}
		
		
		//checking tanslation overlap
		visitedGrid = grid;
		for(int i = 0; i <grid.length;i++) {
			for(int j = 0; j <grid.length;j++) {
				
			}
		}
		return noOfIsland;
	  }
	
	public boolean isBound(int i  , int j, int[][] grid ) {
		
		if(i >=0 && i <grid.length && j >=0 && j < grid[0].length) {
			return true;
		}else {
			return false;
		}
		
	}
	private void checkRegion(int i, int j, int[][] grid, int[][] visitedGrid) {
		
		//topRegion
		if(isBound(i-1, j, grid)) {
			if(visitedGrid[i-1][j]==0 && grid[i-1][j]==1)
			{
				visitedGrid[i][j]=1;
				visitedGrid[i-1][j]=0;
			checkRegion(i-1, j, grid, visitedGrid);
			}
			 
		}
		//leftRegion
		if(isBound(i, j-1, grid)) {
			if(visitedGrid[i][j-1]==0  && grid[i][j-1]==1)
			{
				visitedGrid[i][j]=1;visitedGrid[i][j-1]=1;
			checkRegion(i, j-1, grid, visitedGrid);
			}
		 
		}
		//rightRegion
		if(isBound(i, j+1, grid)) {
			if(visitedGrid[i][j+1]==0  && grid[i][j+1]==1)
			{
				visitedGrid[i][j]=1;visitedGrid[i][j+1]=1;
			checkRegion(i, j+1, grid, visitedGrid);
			}
		
		}
		//bottomRegion
		if(isBound(i+1, j, grid)) {
			if(visitedGrid[i+1][j]==0  && grid[i+1][j]==1)
			{
				visitedGrid[i][j]=1;visitedGrid[i+1][j]=1;
			checkRegion(i+1, j, grid, visitedGrid);
			}
			 
		}
		return;

	}

	public static void main(String[] args) {
		int [][] grid= {{1,1,1,1,1},{1,0,0,0,0},{0,0,0,0,1},{1,1,0,0,1}};
		IslandSearch obj = new IslandSearch();
		System.out.println(obj.numberOfDistinctIslands(grid));
		
	}

}

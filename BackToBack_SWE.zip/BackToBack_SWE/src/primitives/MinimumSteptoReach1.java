/*Rule 1.) If the current value of n is odd, you must subtract one from n. 

    Formally, if n is odd, then the new value of n becomes n-1, and the number of operations increases by one.


Rule 2.) Conversely, if the value of n is even, then you have the option to divide n by two or subtract one from n. 

    Formally, if n is even, then you have the option of setting n to n/2 or n-1. In either case, the number of operations increases by one.

*/
/*
If n is odd, we have no choice but to subtract one from n and increase the number of operations by one. 
Conversely, if n is even, then it is always optimal to divide by two.
This is true because we can never decrease n by more than n/2, which means that subtracting n by one and following some other sequence of operations 
will "intersect" some other number that is reachable in fewer steps by initially dividing by two and
performing an appropriate number of subtraction operations. Therefore, we are always better off dividing 
by two when we are allowed to do so. It can be shown that a simulation of this process will terminate in O(log(n)) time
(due to our ability to aggressively divide by 2). However, we can improve upon this solution by using bitwise operations. 
In particular, observe that every "0" bit in a position other than the least-significant bit will contribute one operation
to our counter (since we must shift this bit to the right by dividing by two). Example: ___________ 10000 (represents 16 under base 2)
would be right-shifted by 1 w/ a division by 2 1000 (represents 8 under base 2) then we would do so again 100 (represents 4 under base 2) 
and so on ___________ Conversely, every "1" bit in a position other than the least-significant bit will contribute two to our counter
(since we must subtract by one and then shift to the right by dividing by two). Example: ___________ 111 (represents 7 under base 2) is odd 
so we subtract 1 110 (represents 6 under base 2) is even so we can divide by 2 11 (represents 3 under base 2) is odd 
so we subtract 1 10 (represents 2 under base 2) can be subtracted by 1 or divided by to get to 1 ___________ Notice
how the odd numbers require a subtraction by 1 and then a right shift to kick out the 0 created by the subtraction by 1.*/

package primitives;

public class MinimumSteptoReach1 {


	  public int minimumStepsToReachOne(int input) {

	    // Case when input is already 1
	    if (input == 1) {
	      return 0;
	    }

	    // It will count the number of operations
	    int operations = 0;

	    // Loop till input is greater than 0
	    while (input != 0) {

	      // if input is odd add 2 to operations
	      // else if input is even add 1 to operations
	      operations += (input & 1) + 1;

	      // Right shift of input 
	      // It is equivalent to dividing the number by 2
	      input >>= 1;
	    }
	    
	    // We substract 2 because we have calculated the ans till it has become 0
	    // So we reduce the number of steps required to convert from 1 to 0 i.e. - 2
	    return operations - 2;
	  }
	  
	  public static void main(String[] args) {
		  
		  MinimumSteptoReach1 obj  = new MinimumSteptoReach1();
		  System.out.println(obj.minimumStepsToReachOne(17));
		
	}
	}

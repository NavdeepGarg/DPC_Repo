package primitives;

import java.util.ArrayList;
import java.util.List;
import java.util.StringTokenizer;
import java.util.function.LongToIntFunction;

public class IPAddressRestoration {
	
	
	public List<String> restoreIpAddresses(String rawIpString) {
		List<String> output = new ArrayList<String>();
		
		restoreIpAddressesUtil(0,new StringBuilder(),output,rawIpString);
	    return output;
	  }

	public boolean countDot(String s) {
		//int x = s.lastIndexOf('.');
		int count =0;
		for(char c : s.toCharArray()) {
			if(c=='.') {
				++count;
			}
			
			
		}
		
		if(count==3) {
			if(s.lastIndexOf('.')<s.length()-1)
			return true;
			else
				return false;
		}else {
			
			return false;
		}
		
	}
	public boolean gotThirdDotAtLast(String s) {
		//int x = s.lastIndexOf('.');
		int count =0;
		for(char c : s.toCharArray()) {
			if(c=='.') {
				++count;
			}
			
			
		}
		
		if(count==3 && s.lastIndexOf('.')==s.length()-1) {
			 return true;
		}else {
			
			return false;
		}
		
	}
	
	
	public boolean verifyIPaddressFormat(String s) {
		
		StringTokenizer str = new StringTokenizer(s,".");
		
		String x = "";
		int count=0;
		boolean valid = true;
		while(str.hasMoreTokens()) {
			x = str.nextToken();
			
			if(count<=3) {
				count++;
				if(Long.valueOf(x)<256 && Long.valueOf(x)>0) {
					continue;
				}else {
					valid =false;
				}
				
			}
			
		}
		
		return valid; 
		
	}
	
	private void restoreIpAddressesUtil(int start, StringBuilder partial, List<String> output,String input) {
		 
		if(countDot(partial.toString())) {
			if(verifyIPaddressFormat(partial.toString())) {
				output.add(partial.toString());
			}else {
				return;
			}
		}
		
		for(int offset =0 ; offset <3 && start+offset < input.length();offset++) {
			
			if(gotThirdDotAtLast(partial.toString()))
			partial.append(input.substring(start, input.length()));
			else
			partial.append(input.substring(start,start+offset+1)+".");	
			restoreIpAddressesUtil(start+1,partial,output,input);
			int x = partial.lastIndexOf(".");
			System.out.println(partial.toString());
			partial.delete(x, partial.length());
			
			
		}
		
		
	}
	
	public static void main(String[] args) {
		
		String s = "255255232132";
		 IPAddressRestoration obj = new IPAddressRestoration();
		 
		 List<String> output = obj.restoreIpAddresses(s);
		 for(String c : output) {
				System.out.println(c); 
				
			}
			
				 
		
	}
	

}

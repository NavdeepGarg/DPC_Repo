//correct

package primitives;

import java.util.ArrayList;
import java.util.List;

public class PowerSetGeneration {
	
	
	public List<List<Integer>> powerset(int[] inputSet) {
		
		List<List<Integer>> output = new ArrayList<List<Integer>>();
		List<Integer> nullList = new ArrayList<>();
		output.add(nullList);
		powerSetUtil(inputSet,0, output);
		
	    return output;
	  }
	
	private void powerSetUtil(int[] inputSet, int i, List<List<Integer>> output) {
		 
		if(i== inputSet.length) {
			return;
		}
		
		int temp = inputSet[i];
		
		int outPutSize = output.size();
		for(int j = 0 ; j < outPutSize; j++) {
			
			List<Integer> tempList = output.get(j);
			
			if(tempList.size()==0) {
				continue;
			}
			List<Integer> newList = new ArrayList<>();;
			newList.addAll(tempList);
			newList.add(temp);
			output.add(newList);
			
		}
		List<Integer> newList = new ArrayList<>();;
		newList.add(temp);
		output.add(newList);
		
		powerSetUtil(inputSet,i+1, output);
		
	}

	public static void main(String[] args) {
		
		int[] arr= {1,2,3};
		
		PowerSetGeneration obj  = new PowerSetGeneration();
		List<List<Integer>> output=	obj.powerset(arr);
		for(List<Integer> tempList : output) {
			
			if(tempList.size()!=0) {
				for(int temp : tempList) {
					System.out.print(temp+" ");
				}
			}
			System.out.println("");
		}
		
	}

}

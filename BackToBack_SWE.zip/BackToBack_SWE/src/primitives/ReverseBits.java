package primitives;


//bit wise understanding
public class ReverseBits {
	
	
	public int reverseBits(int x) {
		
		int output=0 ;
		
		while(x!=0) {
			
			output = output<<1;
			if((x&1)==1) {
				output=output|1;
				
			}
			
			x = x >>1;
			
		}
		
		return output;
		
	}
	
	public static void main(String[] args) {
		
	ReverseBits obj = new ReverseBits();
	System.out.println(obj.reverseBits(4));
		
	}

}

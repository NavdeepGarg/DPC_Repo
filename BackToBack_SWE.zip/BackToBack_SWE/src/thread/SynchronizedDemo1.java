package thread;

class Display{

	public  void wish(String name) {

		System.out.println("Good Morning "+name);

	}

}

class NameThread extends Thread{

	Display d;
	String name;
	NameThread(String name, Display d){
		this.name=name;
		this.d=d;
	}

	@Override
	public void run() {
		synchronized(d) {
			for (int i =0; i < 10; i ++) {

				this.d.wish(this.name);
			}
		}
	}

}

public class SynchronizedDemo1 {
	public static void main(String[] args) {
		Display d = new Display();
		NameThread dhoni = new NameThread("Dhoni", d);
		NameThread yuvraj = new NameThread("Yuvraj", d);
		dhoni.start();
		yuvraj.start();
	}

}

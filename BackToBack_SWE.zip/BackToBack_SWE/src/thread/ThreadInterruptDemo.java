package thread;

class MythreadDemo extends Thread{

	public void run() {
		try {
			for(int i =0; i < 10; i++) {
				System.out.println("I am a Lazy Thread");

				Thread.sleep(2000);

			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			System.out.println("I got Interrupted");

		}
		System.out.println("Coming out of run method");
	}
	
	public void display() {
		System.out.println("dis");
	}
}


public class ThreadInterruptDemo {
	public static void main(String[] args) {
		MythreadDemo d = new MythreadDemo();
		d.start(); // at this line system has two thread one is d and other is main thread		
		d.interrupt();//here main thread is interrupting the thread 'd'
		System.out.println("end of main thread");
		d.display();
	}

}

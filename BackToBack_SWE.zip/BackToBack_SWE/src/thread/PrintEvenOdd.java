package thread;

public class PrintEvenOdd {

	int counter=1;
	int N;
	
	public PrintEvenOdd(int N) {
		// TODO Auto-generated constructor stub
		this.N=N;
	}
	void printEvenNumber() {
		
		while(counter<N) {
			synchronized (this) {
				
			
			while(counter%2==1) {
				try {
					wait();
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			
			System.out.println("Even: "+counter);
			counter++;
			notify();
			}
		}
		
	}
	
void printOddNumber() {
		
		while(counter<N) {
			synchronized (this) {
				
			
			while(counter%2==0) {
				try {
					wait();
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			
			System.out.println("Odd: "+counter);
			counter++;
			notify();
			}
		}
		
	}
	

public static void main(String[] args) {
	
	PrintEvenOdd obj= new PrintEvenOdd(10);
	Thread t1 = new Thread(()->{ 
		//run method
		obj.printEvenNumber();
	});
	
	Thread t2 = new Thread(()->{ 
		//run method
		obj.printOddNumber();
	});
	
	t1.start();
	t2.start();
}
	
}

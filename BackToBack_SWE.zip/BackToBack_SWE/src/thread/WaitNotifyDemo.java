package thread;


class ThreadB extends Thread{
	
	int total;
	@Override
	public void run() {
		synchronized (this) {
			
			System.out.println("Child thread start calculation");
			for(int i =1; i<=100;i++) {
				this.total+=i;
			}
			System.out.println("Child thread sending notification");
			//notifyAll();
			notify();
		}
		
	}
	
}

public class WaitNotifyDemo {
	
	public static void main(String[] args) throws InterruptedException {
		ThreadB b= new ThreadB();
		
		b.start();
		synchronized (b) {
			b.wait();	//Here main thread will go in waiting pool
			System.out.println("Main thread notified from Thread B");
			System.out.println(b.total);
		}
		
	}

}

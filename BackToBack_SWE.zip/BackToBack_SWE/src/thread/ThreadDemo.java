package thread;


class MyThread extends Thread{
	
	@Override
    public void run() {
        for(int i =0 ; i < 5;i++) {
        	System.out.println("i "+i);
        }
    }
	
	
}

public class ThreadDemo {
	
	public static void main(String[] args) {
		
		
		MyThread th = new MyThread();// Thread Instantiation
		
		th.start();// thread started by main thread
		
		
		
	}

			

}

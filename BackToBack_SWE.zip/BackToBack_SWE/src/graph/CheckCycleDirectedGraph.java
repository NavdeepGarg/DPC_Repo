package graph;

import java.util.ArrayList;

public class CheckCycleDirectedGraph {
	
	
	
	
	public boolean isCycle(ArrayList<Integer> graph[], int src) {
		
		boolean []visted= new boolean[graph.length];
		boolean cycleFLAG=false;
		
		for(int i =0 ; i < graph.length; i++) {
			
			visted[i]=true;
			for(int nbr :graph[i]) {
				//nbr as source start its hunt.
				cycleFLAG=isCycleUtil(graph,visted,nbr);
				if(cycleFLAG)
					return true;
			}
			
		}
		return cycleFLAG;
		
	}

	private boolean isCycleUtil(ArrayList<Integer>[] graph, boolean[] visted, int src) {
		if(visted[src]==true) {
			//self loop possibility
			return true;
		}
		visted[src]=true;
		boolean FLAG=false;
		for(int nbr: graph[src]) {
			FLAG=isCycleUtil(graph, visted, nbr);
			if(FLAG) {
				return true;
			}
		}
		visted[src]=false;
		return false;
	}

}

 

//correct
package graph;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.Queue;

class Node{

	private int value;
	private Node leftChild;
	private Node rightChild;
	public int getValue() {
		return value;
	}
	public void setValue(int value) {
		this.value = value;
	}
	public Node getLeftChild() {
		return leftChild;
	}
	public void setLeftChild(Node leftChild) {
		this.leftChild = leftChild;
	}
	public Node getRightChild() {
		return rightChild;
	}
	public void setRightChild(Node rightChild) {
		this.rightChild = rightChild;
	}
	public Node(int value) {
		super();
		this.value = value;
		this.leftChild=null;
		this.rightChild=null;
	}



}


class NodeLevelParent{

	Node node;
	Node parentNode;
	int level;
	public Node getNode() {
		return node;
	}
	public void setNode(Node node) {
		this.node = node;
	}
	public Node getParentNode() {
		return parentNode;
	}
	public void setParentNode(Node parentNode) {
		this.parentNode = parentNode;
	}
	public int getLevel() {
		return level;
	}
	public void setLevel(int level) {
		this.level = level;
	}
	public NodeLevelParent(Node node, Node parentNode, int level) {
		super();
		this.node = node;
		this.parentNode = parentNode;
		this.level = level;
	}

}
public class CousinTree {


	public void findCousins(Node rootNode, Node inputNode){
		
		Queue<NodeLevelParent> queue = new LinkedList<NodeLevelParent>();
		NodeLevelParent firstNode = new NodeLevelParent(rootNode,null,1);
		 
		queue.add(firstNode);
		int inputNodeLevel=0;
		Node excludeParentNode =null;
		while(!queue.isEmpty()) {
			
			NodeLevelParent tempNode = queue.poll();
			Node temp = tempNode.getNode();
			if(temp.getValue()==inputNode.getValue()) {
			inputNodeLevel=tempNode.getLevel();
			excludeParentNode=tempNode.getParentNode();
					break;
			}
			if(temp.getLeftChild()!=null) {
				queue.add(new NodeLevelParent(temp.getLeftChild(), temp, tempNode.getLevel()+1));
			}
			if(temp.getRightChild()!=null) {
				queue.add(new NodeLevelParent(temp.getRightChild(), temp, tempNode.getLevel()+1));
			}
			
			
			
		}
		
		
		List<Integer> list = new ArrayList<Integer>();
		for(NodeLevelParent x : queue) {
			
			if(x.getLevel()==inputNodeLevel && x.getParentNode()!=excludeParentNode) {
				 
				  list.add(x.getNode().getValue());
				  //break;
			}
			else {
				continue;
			}
		}
		 
	 for(int i : list) {
		 System.out.println(i);
	 }
		 	
	}
	
	 
	public static void main(String[] args) {
		
		Node root = new Node(1);
		root.setLeftChild(new Node(2));root.setRightChild(new Node(3));
		root.getLeftChild().setLeftChild(new Node(4));	root.getLeftChild().setRightChild(new Node(5));
		root.getRightChild().setLeftChild(new Node(7));root.getRightChild().setRightChild(new Node(6));
		
		CousinTree obj = new CousinTree();
		obj.findCousins(root, new Node(4));

	}

}

package graph;

public class EnclosedRegions {
	
	int[][] directions= {{-1,0},{1,0},{0,-1},{0,1}};
	
	 public char[][] computeEnclosedRegions(char[][] board) {
		 
		 char[][] boardStatus = new char[board.length][board[0].length];
		 
		 for(int i = 0 ; i <board.length ;i ++) {
			 for(int j =0 ;j < board[0].length; j++) {
				 
				 if(board[i][j]=='X' || board[i][j]=='x')
				 boardStatus[i][j]='T';
				 else {
					 boardStatus[i][j]='X';
				 }
			 }
		 }
		 
		 
		 for(int i = 0 ; i <boardStatus.length ;i ++) {
			 for(int j =0 ;j < boardStatus[0].length; j++) {
				 
				 if((i==0 && boardStatus[i][j]=='X')||(i== boardStatus.length-1 && boardStatus[i][j]=='X')||(j== boardStatus[0].length-1 && boardStatus[i][j]=='X')||(j== 0 && boardStatus[i][j]=='X')) {
					 boardStatus[i][j]='F';
				 }
				 
			 }
			 
		 }
		 
		 for(int i = 0 ; i <board.length ;i ++) {
			 for(int j =0 ;j < board[0].length; j++) {
				 
				 if(board[i][j]=='O' || board[i][j]=='o') {
					 
					 
					 if(isEnclosedRegion(i,j,boardStatus,directions)) {
						 board[i][j]='X';
					 }
				 }
			 }
		 }
		 
		    return board;
		
	  }

	 
	 private boolean isBound(int row, int col,char[][] board) {
		 
		 return row >=0 && row <board.length && col >=0 && col <board[0].length;
	 }
	private boolean isEnclosedRegion(int i, int j, char[][] boardStatus, int[][] directions) {
		
		if(boardStatus[i][j]!='X') {
			//means already set
			return boardStatus[i][j]=='T'?true:false;			
			
		}
		if(boardStatus[i][j]=='X') {
			
			
			for(int[] direction : directions) {
				int rowShift = direction[0];
				int colShift= direction[1];
				int newRow = i+rowShift;
				int newCol = j+colShift;
				if(!isBound(newRow, newCol, boardStatus)) {
					continue;
				}
				
				 if(!isEnclosedRegion(newRow, newCol, boardStatus, directions)) {
					 boardStatus[i][j]='F';
					 return false;
				 }
				 else {
					 boardStatus[i][j]='T';
				 }
			}
		}
		
		return true;
		
	}
	
	public static void main(String[] args) {
		
		
		char[][] board= {{'X', 'X', 'O', 'X', 'X'},{'X', 'X', 'O', 'X', 'X'},{'X', 'X', 'O', 'X', 'X'},{'X', 'X', 'X', 'O', 'X'},{'X', 'X', 'O', 'X', 'X'},
				{'X', 'X', 'O', 'X', 'X'}			
		};
		 
		 for(int i = 0 ; i <board.length ;i ++) {
			 for(int j =0 ;j < board[0].length; j++) {
				 
				 System.out.print(board[i][j]+"  ");
				 
			 }
			 System.out.println("");
		 }
		EnclosedRegions x = new EnclosedRegions();
		board = x.computeEnclosedRegions(board);
		System.out.println("***********");
		 for(int i = 0 ; i <board.length ;i ++) {
			 for(int j =0 ;j < board[0].length; j++) {
				 
				 System.out.print(board[i][j]+"  ");
				 
			 }
			 System.out.println("");
		 }
		
		
	}

}

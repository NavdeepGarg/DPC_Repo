package graph;

//geek for geek
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Stack;




public class TopoSort2 {
	
	ArrayList<ArrayList<Integer>> graph ;
	
	public TopoSort2(int vertex) {
	 graph = new ArrayList<>();
		 for(int i =0 ; i < vertex;i++) {
			 graph.add(new ArrayList<Integer>());
		 }
	}
	
	 
	public void addEdge(int src, int dest) {
		graph.get(src).add(dest);
	}
	
	public void topoSort(ArrayList<ArrayList<Integer>> graph) {
		Stack<Integer> stack= new Stack<>();
		boolean visited[] = new boolean[graph.size()];
		
		for (int i = 0; i < graph.size(); i++)
            if (visited[i] == false)
            	topoSortUtil(graph,visited, stack,i);
		
		
		
		// print stack order
		   while (stack.empty() == false)
	            System.out.print(stack.pop() + " ");
	}

	private void topoSortUtil(ArrayList<ArrayList<Integer>> graph, boolean[] visited, Stack<Integer> stack, int i) {
		
		
		//adjacent edges
		ArrayList<Integer> edgeList= graph.get(i);
		visited[i]=true;
		
		for(int dest : edgeList) {
			
			if(!visited[dest]) {
				topoSortUtil(graph, visited, stack, dest);
			}
			
		}
		
		stack.push(i);
	}
	
	public static void main(String[] args) {
		
		//create graph;
		TopoSort2 o = new TopoSort2(4);
		o.addEdge(0, 1);o.addEdge(2, 0);o.addEdge(2, 3);o.addEdge(1, 3);
		o.topoSort(o.graph);
	}

}

package graph;

import java.util.ArrayList;

class Pair{
	
	int first; 
	int second;
	public Pair(int first, int second) {
		super();
		this.first = first;
		this.second = second;
	}
	 
	
	
	
	
}

public class DisjointSetUnion {

	
	
	
	
	public void union(int node1, int node2, int[] parentArray) {
		
		
		int x = find(node1,parentArray);
		int y = find(node2,parentArray);
		if(x==y && x==-1) {
			//first time union for disjoint element
			parentArray[node1]=node2;
		}
		
		if(x==y) {
			//part of same tree.. so nothing is required to be done.
			
		}
		else
		parentArray[node1]=y;
		
	}
	
	
	//return absolute root value
	public int find(int node, int[] parentArray) {
		
		if(parentArray[node]==-1) {
			return node;
		}
		return find(parentArray[node],parentArray);
		
	}
	
	//this can only be performed for undirected graph. For DSU finding a cycle in directed graph cycle is not allowed
	public boolean isGraphCyclic(int[] parentArray,ArrayList<Pair> graph ) {
		
		int parent1;
		int parent2;
		for(Pair p : graph) {
			 
			parent1= find(p.first,parentArray);
			parent2=find(p.second,parentArray);
			if(parent1==parent2 && parent1!=-1) {
				return true;
			}
			union(p.first, p.second, parentArray);
		}
		return false;
		
	}
			
public static void main(String[] args) {
	//cyclic pair
	Pair p1 = new Pair(0, 1);Pair p2 = new Pair(1, 2);
	//Pair p3 = new Pair(0, 2);
	int noofVertex=3;
	ArrayList<Pair> edgeList= new ArrayList<>();
	edgeList.add(p1);edgeList.add(p2);
	//edgeList.add(p3);
	DisjointSetUnion o = new DisjointSetUnion();
	int[] parentarray= new int[noofVertex];
	 for(int i =0 ; i < parentarray.length;i++) {
		 parentarray[i]=-1;
	 }
	System.out.println(o.isGraphCyclic(parentarray, edgeList));
}	
}

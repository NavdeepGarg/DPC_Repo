package graph;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.StringTokenizer;
import java.util.stream.IntStream;


public class FrogInMaze {

	    public static void main(String[] args) throws IOException {
	        BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(System.in));

	        String[] firstMultipleInput = bufferedReader.readLine().replaceAll("\\s+$", "").split(" ");

	        int n = Integer.parseInt(firstMultipleInput[0]);

	        int m = Integer.parseInt(firstMultipleInput[1]);

	        int k = Integer.parseInt(firstMultipleInput[2]);

	        char graph[][]= new char [n][m];
	        IntStream.range(0, n).forEach(nItr -> {
	            try {
	                String row = bufferedReader.readLine();
	                
	                
	                // Write your code here
	                
	                StringTokenizer token = new StringTokenizer(row," ");
	                int i =0;
	                while(token.hasMoreElements())
	                	graph[nItr][i++]= token.nextToken().charAt(0);
	                
	            } catch (IOException ex) {
	                throw new RuntimeException(ex);
	            }
	        });

	        IntStream.range(0, k).forEach(kItr -> {
	            try {
	                String[] secondMultipleInput = bufferedReader.readLine().replaceAll("\\s+$", "").split(" ");

	                int i1 = Integer.parseInt(secondMultipleInput[0]);

	                int j1 = Integer.parseInt(secondMultipleInput[1]);

	                int i2 = Integer.parseInt(secondMultipleInput[2]);

	                int j2 = Integer.parseInt(secondMultipleInput[3]);

	                // Write your code here
	                 graph[][]
	                
	            } catch (IOException ex) {
	                throw new RuntimeException(ex);
	            }
	        });

	        // Write your code here

	        bufferedReader.close();
	    }
	}

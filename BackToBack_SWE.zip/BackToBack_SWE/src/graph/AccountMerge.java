package graph;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map.Entry;

import com.sun.xml.internal.ws.message.EmptyMessageImpl;

import java.util.Set;
import java.util.TreeSet;

public class AccountMerge {

	public static List<List<String>> accountsMerge(List<List<String>> accounts) {

	 

		HashMap<String,HashMap<String,String>> output = new HashMap<>();

		for(int i =0 ; i< accounts.size();i++) {

			List<String> fullString=accounts.get(i);
			String name = fullString.get(0);

			HashMap<String, String> tempMap = output.getOrDefault(name, new HashMap<String,String>());
			for(int j = 1 ; j < fullString.size();j++) {
				tempMap.put(fullString.get(j), name);
			}

			output.put(name, tempMap);

		}

		List<List<String>> res = new ArrayList<List<String>>();
		for(Entry<String,HashMap<String,String>> entry : output.entrySet()) {

			HashMap<String,String> temp = entry.getValue();
			int tempSize= temp.size();
			Set<String> tempSet = new HashSet<>();
			for(Entry<String, String> entryTemp : temp.entrySet()) {
				tempSet.add(entryTemp.getKey());
			}
			if(tempSet.size()==tempSize) {
				//all were unique
				List<String> resList =new ArrayList<>();

				for(Entry<String, String> entryTemp : temp.entrySet()) {
					resList.add(entry.getKey());
					resList.add(entryTemp.getKey());
				}
				res.add(resList);
			}else {

				List<String> resList =new ArrayList<>();
				resList.add(entry.getKey());
				for(Entry<String, String> entryTemp : temp.entrySet()) {
					
					resList.add(entryTemp.getKey());
				}
				res.add(resList);
			}
		}


		return res;
	}
	
	
public static void main(String[] args) {
	String[][] accounts= {{"John","johnsmith@mail.com","john_newyork@mail.com"},{"John","johnsmith@mail.com","john00@mail.com"},{"Mary","mary@mail.com"},{"John","johnnybravo@mail.com"}};
	
	List<List<String>> account2 = new ArrayList<>();
	for(String[] x : accounts) {
		account2.add(Arrays.asList(x));
	}
	System.out.println(accountsMerge(account2));
} 


}

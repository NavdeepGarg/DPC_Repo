//correct

/**
 * Definition for a binary tree node.
 * public class TreeNode {
 *     int val;
 *     TreeNode left;
 *     TreeNode right;
 *     TreeNode() {}
 *     TreeNode(int val) { this.val = val; }
 *     TreeNode(int val, TreeNode left, TreeNode right) {
 *         this.val = val;
 *         this.left = left;
 *         this.right = right;
 *     }
 * }
 */

class Sum{
    int sum;
}
class Solution {
    public int rangeSumBST(TreeNode root, int low, int high) {
        Sum s = new Sum();
        s.sum=0;
         
		rangeSumBSTUtil(s,root,low,high);
        return s.sum;

    }
    
    private void rangeSumBSTUtil(Sum s, TreeNode root, int low, int high) {
		
		if(root==null) {
			return  ;
		}
		
		if(root.val >=low && root.val<=high) {
			
			s.sum+=root.val;
			
		}
        
		rangeSumBSTUtil( s,  root.left,  low,  high) ;
        rangeSumBSTUtil( s,  root.right,  low,  high) ;
		 
	}
}
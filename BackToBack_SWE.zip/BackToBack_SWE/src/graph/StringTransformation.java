//correct
package graph;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Queue;
import java.util.Set;

public class StringTransformation {
	
	
	public int distance(String beginWord, String endWord, List<String> wordList) {
	    if (!wordList.contains(endWord)) {
	      return -1;
	    }
	    
	    Queue<String> queue = new LinkedList<>();
	    Set<String> set = new HashSet<>();
	    queue.add(beginWord);
	    int currentLevel=1;
	    int itemLeftToProcess=1;
	    String tempword="";
	    while(!queue.isEmpty()) {
	    	
	    	tempword= queue.poll();
	    	if(tempword.equals(endWord)) {
	    		return currentLevel-1;
	    	}
	    	
	    	for(String s : wordList) {
	    		
	    		if(isWordDifferenceOne(s,tempword) && !set.contains(tempword)) {
	    			queue.add(s);
	    			
	    		}
	    		
	    		
	    		
	    	}
	    	set.add(tempword);
	    	itemLeftToProcess--;
	    	 if (itemLeftToProcess == 0) {
	    	        currentLevel++;
	    	        itemLeftToProcess = queue.size();
	    	 }
	    }
	    
	    return -1;
	    
	}
	
	private boolean isWordDifferenceOne(String s, String tempword) {
		 
		int count=0;
		for(int i = 0 ; i < s.length() && count <2 ;i++) {
			if(s.charAt(i) == tempword.charAt(i)) {
				continue;
			}else {
				count++;
			}
			
			
		}
		
		if(count==1)
			return true;
		return false;
	}

	public static void main(String[] args) {
		
		String beginWord = "dog",endWord = "lot";
		StringTransformation obj  = new StringTransformation();
		List<String> wordList = new ArrayList<String>();
		wordList.add("dot");wordList.add("mot");wordList.add("lot");
		
		int dist =obj.distance(beginWord, endWord, wordList);
		System.out.println("dist  : "+dist);
	}

}

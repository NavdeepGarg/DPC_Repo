package graph;
//here graph is stored in the form of 2D array
import java.util.HashSet;
import java.util.LinkedList;
import java.util.Queue;
import java.util.Set;


enum Color{
	
	BLACK,WHITE,UNCOLORED;
}



class Vertex{
	
	private int vertexNumnber;
	private int vertexColor;
	public int getVertexNumnber() {
		return vertexNumnber;
	}
	public void setVertexNumnber(int vertexNumnber) {
		this.vertexNumnber = vertexNumnber;
	}
	public int getVertexColor() {
		return vertexColor;
	}
	public void setVertexColor(int vertexColor) {
		this.vertexColor = vertexColor;
	}
	public Vertex(int vertexNumnber, int vertexColor) {
		super();
		this.vertexNumnber = vertexNumnber;
		this.vertexColor = vertexColor;
	}
	
	
	
}

public class BiPartiteGraph {

	
public Color[] initializeVertexColor(int[][] adjList) {
	
	Color[] colorList = new Color[adjList.length];
	
	for(int i =0 ; i <adjList.length;i++) {
		
		colorList[i]=Color.UNCOLORED;
		
	}
	
	return colorList;
	
}
	
	




	public Color colorOpposite(int vertex, Color[] colorVertex) {
			
			return (colorVertex[vertex] == Color.BLACK)? Color.WHITE:Color.BLACK;
		
	}

	 public boolean isBipartite(int[][] adjList) {
		 
		 Queue<Integer> bfs = new LinkedList<>(); 
		 Set<Integer> seenSet = new HashSet<>();
		 Color[] vertexColors = this.initializeVertexColor(adjList); 
		 
		 for(int i =0 ; i <adjList.length;i++) {

			 //i == vertex
			 if(!seenSet.contains(i))
			 {
				 bfs.add(i);
				 vertexColors[i]=Color.WHITE;
				 while(!bfs.isEmpty()) {
					 
					 int vertex = bfs.poll();
					 for(int adj : adjList[vertex]) {
						 
						 Color adjColor = vertexColors[adj];
						 if(adjColor==Color.UNCOLORED) {
							 vertexColors[adj]=this.colorOpposite(vertex,vertexColors);
							 
						 }
						 else if(adjColor==vertexColors[vertex]) {
							 return false;
						 }
						 
						 if(!seenSet.contains(adj)) {
							 bfs.add(adj);
							 seenSet.add(adj);
						 }
				 }
			 } 

		 }
			 
		 }
		 
		 return true; 
		 
  }
	
	 
	 
	
	public static void main(String[] args) {
		
	}
}

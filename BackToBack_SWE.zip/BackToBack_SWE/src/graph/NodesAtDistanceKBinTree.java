package graph;

import java.util.ArrayList;
import java.util.List;

class TreeNode{
	private int value;
	private TreeNode left;
	private TreeNode right;
	public int getValue() {
		return value;
	}
	public void setValue(int value) {
		this.value = value;
	}
	public TreeNode getLeft() {
		return left;
	}
	public void setLeft(TreeNode left) {
		this.left = left;
	}
	public TreeNode getRight() {
		return right;
	}
	public void setRight(TreeNode right) {
		this.right = right;
	}
	public TreeNode(int value) {
		super();
		this.value = value;
	}

}

public class NodesAtDistanceKBinTree {

	public List<Integer> distanceK(TreeNode root, int x, int k) {

		if(root==null) {
			return null;
		}

		List<Integer> outputList = new ArrayList<Integer>();
		TreeNode carryforwardNode = root;
		int distTraveled=0;
		int direction=0; //0 is for left

		distanceK(root.getLeft(),carryforwardNode,x,distTraveled+1,k,0,outputList);
		distanceK(root.getRight(),carryforwardNode,x,distTraveled+1,k,1,outputList);

		System.out.println(outputList);
		return outputList;
	}




	private void distanceK(TreeNode node, TreeNode carryforwardNode, int x, int distTraveled, int k, int direction,
			List<Integer> outputList) {

		if(node==null) {
			return ;
		}
		if(node.getValue()!=x) {
			if(distTraveled<k) {

				distanceK(node.getLeft(),carryforwardNode,x,distTraveled+1,k,direction,outputList);
				distanceK(node.getRight(),carryforwardNode,x,distTraveled+1,k,direction,outputList);
				return;
			}
			if(distTraveled==k) {
				distanceK(node.getLeft(),carryforwardNode.getLeft(),x,distTraveled+1,k,0,outputList);
				distanceK(node.getRight(),carryforwardNode.getRight(),x,distTraveled+1,k,1,outputList);
				return;
			}


		}

		if(node.getValue()==x) {
			if(distTraveled<k) {

				ascendfromcarrynode( carryforwardNode,distTraveled,k,direction,outputList);
				descendfromtargetnode(node.getRight(),1,k,1,outputList);
				descendfromtargetnode(node.getLeft(),1,k,0,outputList);
				return;
			}
			if(distTraveled==k) {
				outputList.add(carryforwardNode.getValue());
				
				descendfromtargetnode(node.getRight(),1,k,1,outputList);
				descendfromtargetnode(node.getLeft(),1,k,0,outputList);
				return;
			}
		}
	}




	private void ascendfromcarrynode(TreeNode carryforwardNode, int distTraveled, int k, int direction, List<Integer> outputList) {
		 TreeNode nextNode;
		 if(direction==0) {
			 nextNode=carryforwardNode.getRight();
		 }
		 else {
			 nextNode = carryforwardNode.getLeft();
		 }
		 
		 if(nextNode==null)
			 return;
		 
		 descendfromtargetnode(nextNode,distTraveled+1,k,direction,outputList);
	}




	private void descendfromtargetnode(TreeNode node, int distTraveled, int k, int direction, List<Integer> outputList) {
		 if(node==null) {
			 return;
		 }
		 
		 if(distTraveled==k) {
			 outputList.add(node.getValue());
			 return;
		 }
		 if(distTraveled<k) {
			 descendfromtargetnode(node.getRight(),distTraveled+1,k,1,outputList);
				descendfromtargetnode(node.getLeft(),distTraveled+1,k,0,outputList);
				return;
		 }
		
	}




	public static void main(String[] args) {
		
		TreeNode root = new TreeNode(1);
		TreeNode a = new TreeNode(3);
		TreeNode b = new TreeNode(2);
		TreeNode c = new TreeNode(4);
		TreeNode d = new TreeNode(6);
		TreeNode e = new TreeNode(7);	
		
		root.setLeft(a);root.setRight(b);
		a.setLeft(c);a.setRight(d);
		b.setLeft(null);b.setRight(e);
		c.setLeft(null);c.setRight(null);d.setLeft(null);d.setRight(null);e.setLeft(null);e.setRight(null);
		
		
		NodesAtDistanceKBinTree obj  = new NodesAtDistanceKBinTree();
		obj.distanceK(root, 3, 1);
		

	}

}

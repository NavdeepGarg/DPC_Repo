package graph;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

//correct
public class ClonedGrph { 
	
	class Node {
	    public int val;
	    public List<Node> neighbors;
	    public Node() {
	        val = 0;
	        neighbors = new ArrayList<Node>();
	    }
	    public Node(int _val) {
	        val = _val;
	        neighbors = new ArrayList<Node>();
	    }
	    public Node(int _val, ArrayList<Node> _neighbors) {
	        val = _val;
	        neighbors = _neighbors;
	    }
	}
	
	
	
		Node cloneNode;
		HashMap<Integer,Node> map;
		boolean visited[];
		
		private void  dfs(Node node) {
		
			if(node==null) {
				return ;
			} 
		
			visited[node.val] =true;
			Node cloneNode = map.get(node.val);
			for(Node nbrs : node.neighbors) {
		
				if(map.containsKey(nbrs.val)) {
					cloneNode.neighbors.add(map.get(nbrs.val));
				}
				else {
					Node temp = new Node(nbrs.val);
					cloneNode.neighbors.add(temp);
					map.put(temp.val, temp);
				}
		
				if(!visited[nbrs.val]) {
					dfs(nbrs);
				}
			}
		
		
		
		
		}
		public Node cloneGraph(Node node) {
		
			if(node==null) return null;
		
		
			cloneNode = new Node(node.val);
			visited=new boolean[101];
			map= new HashMap<>();
			map.put(node.val, cloneNode);
			dfs(node);
		
			return cloneNode;
		
		
		
		
		}}

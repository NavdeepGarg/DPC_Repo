package graph;

class ListNode{
	
	public int val;
	public ListNode next;
	public ListNode(int val) {
		super();
		this.val = val;
	}
	
	
}


public class LinkedList {
	
	
	public static void main(String[] args) {
		
		
		
	}

}

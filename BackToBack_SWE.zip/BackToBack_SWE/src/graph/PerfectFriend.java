
//You have to find in how many ways can we select a pair of students such that both students are from different clubs.

package graph;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;

public class PerfectFriend {
	
	public static class Edge{
		int src;
		int dest;
		public Edge(int src, int dest) {
			super();
			this.src = src;
			this.dest = dest;
		}
		
		
	}

	
	public static void main(String[] args) throws NumberFormatException, IOException {
		
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		System.out.println("Enter no of vertex");
		int  n = Integer.parseInt(br.readLine());

		System.out.println("Enter no of edges");
		int k = Integer.parseInt(br.readLine());
		
		//for no of vertex
		ArrayList<Edge>[] graph=new ArrayList[n];
		for(int v =0 ; v<n ;v++) {
			graph[v]=new ArrayList<Edge>();
		}
		//for no of edges
		for(int v =0 ; v<k ;v++) {
			System.out.println("Enter edges -- src and dest : ");
			String[] parts=br.readLine().split(" ");
			
			int src = Integer.parseInt(parts[0]);
			int dest= Integer.parseInt(parts[1]);
			
			graph[src].add(new Edge(src, dest));
			graph[dest].add(new Edge(dest,src));
		}
		
		ArrayList<ArrayList<Integer>> components=new ArrayList<>();
		boolean[] visited=new boolean [n];
		for(int v=0; v< n; v++) {
			if(visited[v]==false) {
			ArrayList<Integer> component= new ArrayList<Integer>();
			
			checkConnectedComponents(graph,v, components,component,visited);
			components.add(component);
			}
		}
		System.out.println("no of components "+ components.size());
		// no. of pairs possible
		int pairs=0;
		int totalsize=components.size();
		for(int v =0 ; v<components.size();v++) {
			
			pairs+= components.get(v % totalsize ).size() *components.get((v+1) % totalsize).size();
			
			
		}
		System.out.println("no of pairs "+ pairs);
	}


	private static void checkConnectedComponents(ArrayList<Edge>[] graph,int src, ArrayList<ArrayList<Integer>> components,
			ArrayList<Integer> component, boolean[] visited) {
		 	
			if(visited[src]==true) {
				return;
				
			}
			component.add(src);
			ArrayList<Edge> neighbourList = graph[src];
			 visited[src]= true;
			for(Edge e : neighbourList) {
				if(visited[e.dest]==false) {				 
				checkConnectedComponents(graph, e.dest, components, component, visited);
				}
			}
		
	}
}

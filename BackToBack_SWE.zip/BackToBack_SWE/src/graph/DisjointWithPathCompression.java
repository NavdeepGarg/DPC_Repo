package graph;

class UnionFind{

	int[] parent;
	int[] height;
	public UnionFind(int size) {
		parent= new int[size];
		height= new int[size];

		for(int i =0 ; i < size;i++) {
			parent[i]=i;
		}

	}
	//absolute parent
	public int find(int x) {

		if(parent[x]==x) {
			return x;
		}

		return parent[x]=find(parent[x]);

	}

	public void union(int x, int y ) {
		int parX= find(x);
		int parY= find(y);
		if(parX==parY) {
			return;
		}
		if(height[parX] > height[parY]) {
			parent[parY]=parX;
		}else if(height[parX] ==height[parY]) {
			parent[parY]=parX;
			height[parX]+=1;
		}
		else {
			parent[parX]=parY;
		}
		 
	}


}

public class DisjointWithPathCompression {
 



	public static void main(String[] args) {

	}

}

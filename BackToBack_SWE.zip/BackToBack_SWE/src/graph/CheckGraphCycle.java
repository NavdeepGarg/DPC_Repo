package graph;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.Queue;

public class CheckGraphCycle {
	
	
	public  static class Edge{
		
		int src;
		int dest;
		public Edge(int src, int dest) {
			super();
			this.src = src;
			this.dest = dest;
		}
		
	}

	public static void main(String[] args) throws NumberFormatException, IOException {
		//Taking Input
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		System.out.println("Enter no of vertex");
		int  n = Integer.parseInt(br.readLine());

		System.out.println("Enter no of edges");
		int k = Integer.parseInt(br.readLine());
		
		//for no of vertex
		ArrayList<Edge>[] graph=new ArrayList[n];
		for(int v =0 ; v<n ;v++) {
			graph[v]=new ArrayList<Edge>();
		}
		//for no of edges
		for(int v =0 ; v<k ;v++) {
			System.out.println("Enter edges -- src and dest : ");
			String[] parts=br.readLine().split(" ");
			
			int src = Integer.parseInt(parts[0]);
			int dest= Integer.parseInt(parts[1]);
			
			graph[src].add(new Edge(src, dest));
			graph[dest].add(new Edge(dest,src));
		}
		
		
		//Traverse Graph3
		
		boolean[] visited=new boolean [n];
		boolean cycle = false;
		for(int src =0 ; src < graph.length;src++) {
			if(!visited[src])
			cycle=isCyclic(graph, src,visited);
			
			if(cycle) {
				break;
			}
		}
		
		
		System.out.println("cycle "+cycle);
		
		
		
	}

	//using adjacency list
	private static boolean isCyclic(ArrayList<Edge>[] graph, int src, boolean[] visited) {
		//visited[src]=true;
		Queue<Integer> queue = new LinkedList<>();
		queue.add(src);
		while(!queue.isEmpty()) {

			int start = queue.poll();

			if(visited[start]) {
				return true;
			}

			visited[start]=true;
			for(Edge neighbourEdge : graph[start]) {
				if(!visited[neighbourEdge.dest]) {
					queue.add(neighbourEdge.dest);
				}

			}

		}

		return false;
	} 
	
	
}

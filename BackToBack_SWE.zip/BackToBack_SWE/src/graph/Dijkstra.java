package graph;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.PriorityQueue;
import java.util.Set;

public class Dijkstra {

	int V ;
	int E;
	
	
	 
	public int[] dijkstraMetric(List<List<VertexLocal> > adj_list,int V, VertexLocal src_vertex) {
		
		
		PriorityQueue<VertexLocal> queue = new PriorityQueue<VertexLocal>();
		
		Set<Integer> visited = new HashSet<>();
		int[] dist = new int[V];
		for (int i = 0; i < V; i++) 
            dist[i] = Integer.MAX_VALUE; 
		queue.add(src_vertex);
		dist[src_vertex.getId()]=0;
		
		while(!queue.isEmpty()) {
			
			VertexLocal curr = queue.poll(); //extract minimum
			visited.add(curr.getId());
			int u = curr.getId();
			 int edgeDistance = -1; 
		        int newDistance = -1; 
		   
			 // process all neighbouring nodes of u 
		        for (int i = 0; i < adj_list.get(u).size(); i++) { 
		        	VertexLocal v = adj_list.get(u).get(i); 

		        	//  proceed only if current VertexLocal is not in 'visited'
		        	if (!visited.contains(v.getId())) { 
		        		edgeDistance = v.getDistFromSource(); //edge weight
		        		newDistance = dist[u] + edgeDistance; 

		        		// compare distances 
		        		if (newDistance < dist[v.getId()]) 
		        			dist[v.getId()] = newDistance; 

		        		// Add the neighbour vertex to the PriorityQueue 
		        		queue.add(new VertexLocal(v.getId(), dist[v.getId()])); 
		        	} 
		        }  
		}
		return dist;
	}
	
	public static void main(String[] args) {
		 
		int V=4;
		List<List<VertexLocal> > adj_list = new ArrayList<List<VertexLocal>>();
		
		for(int i =0 ; i < V; i++) {
			adj_list.add(new ArrayList<VertexLocal>());
		}
		
		adj_list.get(0).add(new VertexLocal(1, 5));
		adj_list.get(0).add(new VertexLocal(2, 4));
		adj_list.get(1).add(new VertexLocal(3, 3));
		adj_list.get(2).add(new VertexLocal(1, 6));
		adj_list.get(3).add(new VertexLocal(2, 2));
		
		Dijkstra obj  = new Dijkstra();
		int[] dist = obj.dijkstraMetric(adj_list, V, new VertexLocal(0, 0));
		
		System.out.println(dist);
			
		
	}
}
 

class VertexLocal implements Comparator<VertexLocal>{
	
	int id;
	int distFromSource; 
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getDistFromSource() {
		return distFromSource;
	}
	public void setDistFromSource(int distFromSource) {
		this.distFromSource = distFromSource;
	}
 
	public VertexLocal(int id, int distFromSource) {
		super();
		this.id = id;
		this.distFromSource = distFromSource; 
	}
	@Override
	public int compare(VertexLocal o1, VertexLocal o2) {
		if(o1.getDistFromSource()-o2.getDistFromSource()>0) {
			return 1;
		}
		else if(o1.getDistFromSource()-o2.getDistFromSource()<0) {
			return -1;
		}
		else {
			return 0;	
		}
		
	}
	
	
}

 
	

 
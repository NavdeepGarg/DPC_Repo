package erichto.leet;

public class BitWiseAndRange {
	
	
	public static void main(String[] args) {
		
		int number1=-1, number2=7;
		int ans=0;
		
		for(int bit =31 ; bit >=0 ; bit--) {
			if((number1&(1<<bit)) != (number2&(1<<bit))) {
				break;
			}
			ans|=(number1&(1<<bit));
		}
		
		
		System.out.println(ans);
		
	}

}

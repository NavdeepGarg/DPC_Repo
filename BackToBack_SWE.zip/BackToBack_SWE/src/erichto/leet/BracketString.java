package erichto.leet;

import java.util.Stack;

import com.sun.org.apache.regexp.internal.recompile;

public class BracketString {

	//without extra space
	public static boolean function2(String str) {


		int balance=0;
		for(int i = 0 ;i < str.length();i++) {
			if(str.charAt(i)==')') {
				balance--;
			}
			else {
				balance ++;
			}
			if(balance<0) {
				return false;
			}
		}
		balance=0;
		for(int i = str.length()-1 ;i >=0;i--) {
			if(str.charAt(i)=='(') {
				balance--;
			}
			else {
				balance ++;
			}
			if(balance<0) {
				return false;
			}
		}

		return true;
	}


	//with extra space
	public static boolean function(String str) { 

		Stack<Integer> stackBrackets = new Stack<>();
		Stack<Integer> stackStars = new Stack<>();

		for(int i = 0 ;i < str.length();i++) {
			if(str.charAt(i)=='(') {
				stackBrackets.push(i);
			}
			else if(str.charAt(i)=='*') {
				stackStars.push(i);
			}
			else {

				if(!stackBrackets.isEmpty()) {
					stackBrackets.pop();
				}else if(!stackStars.isEmpty()) {
					stackStars.pop();
				}
				else
					return false;
			}
		}



		while(!stackBrackets.isEmpty()) {

			int index = stackBrackets.pop();
			if(stackStars.isEmpty()) {
				return false;
			}
			int starIndex=stackStars.pop();
			if(starIndex>index) {
				stackBrackets.pop();
			}
			else {
				return false;
			}
		}

		return true;	

	}



	public static void main(String[] args) {

		String str = "(*)())(";

		System.out.println(function(str));
		System.out.println(function2(str));


	}

}

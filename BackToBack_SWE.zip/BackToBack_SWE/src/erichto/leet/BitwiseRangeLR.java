package erichto.leet;

public class BitwiseRangeLR {
	
	int bitsCount=32;
	int MAX=100000;
	int[][] prefixCountArray = new int[bitsCount][MAX] ;
	
	public void  calPrefixCountArray(int[] arr){
		
		for(int i = 0  ; i < bitsCount;i++) {
			
			int firstBitValue =(arr[0])&(1<<i);
			prefixCountArray[i][0]=firstBitValue;
			for(int j = 1; j < arr.length;j++) {
				prefixCountArray[i][j]=(arr[j])&(1<<i);
				prefixCountArray[i][j]+=prefixCountArray[i][j-1]; 
			}
			
			
			
		}
	}
	
	//arr ={a,b,c,d};
	public int calAnd(int l , int r , int[] arr) {
		
		int noOFBitSet=0;
		int ans=0;
		int range=r-l+1;
		for(int i = 0;i <=31; i++) {
			if(l==0) {
				noOFBitSet=prefixCountArray[i][r]-prefixCountArray[i][l];
				 
			}else {
			 
				noOFBitSet=prefixCountArray[i][r]-prefixCountArray[i][l-1];
				
			}
			
			if(noOFBitSet==range) {
				ans|=(1<<i);
			}
			
		}
		
		return ans;
		
		
	}
	
	
	public static void main(String[] args) {
		
		
		int arr[] = { 7, 5, 3, 5, 2, 3 };
	    int n = arr.length;
	   BitwiseRangeLR obj = new BitwiseRangeLR();
	   obj.calPrefixCountArray(arr);
	   System.out.println( obj.calAnd(1, 3, arr));
	    
	}

}

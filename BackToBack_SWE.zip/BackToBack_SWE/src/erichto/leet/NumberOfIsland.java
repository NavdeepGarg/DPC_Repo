package erichto.leet;

import java.util.LinkedList;
import java.util.Queue;


class Cordinate{
	
	int x;
	int y;
	public Cordinate(int x, int y) {
		super();
		this.x = x;
		this.y = y;
	}
	
}

//solution will use BFS.
public class NumberOfIsland {
	
	
	
	public boolean inside(int[][] grid, int x, int y ) {
		
		if(x<0 || y <0 || x>=grid.length ||y>=grid[0].length) {
			return false;
		}
		return true; 
		
		
	}
	
	public int coundIsland(int[][] grid) {
		
		boolean[][] visited= new boolean[grid.length][grid[0].length];
		int[][] direction= {{1,0},{0,1},{-1,0},{0,-1}}; 
		Queue<Cordinate> queue = new LinkedList<>();
		int H= grid.length;
		int W= grid[0].length;
		int answer=0;
		for(int row =0 ; row < H;row++) {
			for(int col =0 ; col < W;col++) {
				
				if(!visited[row][col] && grid[row][col]==1) {
					//checking to get the island
					answer++;
					Cordinate c = new Cordinate(row, col);
					//applying BFS
					visited[row][col]=true;
					queue.add(c);
					while(!queue.isEmpty()) {
						
						Cordinate c1= queue.poll();
						//evaluate neighbours
						for(int[] x : direction) {
							int newRow= c1.x+x[0];
							int newCol = c1.y+x[1];
							if(inside(grid, newRow, newCol) && !visited[newRow][newCol] && grid[newRow][newCol]==1) {
								queue.add(new Cordinate(newRow, newCol));
							}
							
						}
					}
					
				}
				
			}
			
		}
		
		return answer;
	}

}

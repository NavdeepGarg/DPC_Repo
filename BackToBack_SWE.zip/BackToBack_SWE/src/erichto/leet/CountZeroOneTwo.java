package erichto.leet;

import java.util.HashMap;
import java.util.Map;

public class CountZeroOneTwo {

	public static int countZeroandOnesandTwo(int[] nums) {

		Map<String,Integer> map = new HashMap<>();
		map.put("0#0", -1);
		//x1-x0 # x2-x1
		int x0=0;
		int x1=0;
		int x2=0;
		int ans=0;
		for(int i =0 ; i < nums.length;i++) {
			if(nums[i]==0) {
				x0++;

			}
			if(nums[i]==1) {
				x1++;

			}
			if(nums[i]==2) {
				x2++;

			}
			int x10= x1-x0;
			int x21= x2-x1;
			String temp = x10+"#"+x21;
			if(map.containsKey(temp)) {
				int id= map.get(temp);
				int len  = i-id;
				if(ans<len) {
					ans=len;
				}
			}else {
				map.put(temp, 1);
			}
		}
		
		System.out.println(map);
		return ans;
	}


	public static void main(String[] args) {
		
		//int[] nums= {0,1,2};
		int[] nums= {1,1,2,0,1,0,1,2,1,2,2,0,1};
		System.out.println(countZeroandOnesandTwo(nums));

	}

}

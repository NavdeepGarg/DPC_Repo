package erichto.leet;

public class FindingPivot {
	
	
	public static int findPivotIndex(int[] num, int start, int end) {
		
		if(start >end) {
			return -1;
		}
		int mid =(end-start)/2 +start;
		int pivotIndex=0;
		if(mid-1>=0 && mid+1< num.length) {
			
			if(num[mid] >num[mid+1]) {
				pivotIndex=mid;
				return pivotIndex;
			}
			
			int op1 = findPivotIndex(num, start, mid-1);
			int op2 = findPivotIndex(num, mid+1, end);
			if(op1 !=-1) {
				pivotIndex =op1;
				return pivotIndex;
			}
			else {
				return pivotIndex =op2; 
			}
			
		}
		
		else {
			return -1;
		}
	}
	
	
	public static void main(String[] args) {
		
		//int num[]= {6,7,0,1,2,4,5};
		//int num[]= {4,5,6,7,8,9,1};
		int num[]= {4,5,6,7,0,1,2};
		int target = 0;
		int pivotIndex=findPivotIndex(num, 0, num.length-1);
		System.out.println(pivotIndex);
		int start=0, end=0;
		if(pivotIndex !=-1) {
			if(target <= num[pivotIndex] && target >=num[start]) {
				start=0;end=pivotIndex;
				
			}else {
				start=pivotIndex+1;
				end =num.length-1;
				
				
			}
			
			int idx  = findInCustomBS(num,start,end,target);
			System.out.println("IDx "+idx);
			
		}
		
	}


	private static int findInCustomBS(int[] num, int start, int end, int target) {
			
		if(start>end) {
			return -1;
		}
			int mid=(end-start)/2 +start;
			if(num[mid]==target) {
				
				return mid;
			}
			else if(num[mid]>target) {
				return findInCustomBS(num, start, mid-1, target); 
				
			}else {
				
				return findInCustomBS(num, mid+1, end, target); 
			}
			
		
	}

}

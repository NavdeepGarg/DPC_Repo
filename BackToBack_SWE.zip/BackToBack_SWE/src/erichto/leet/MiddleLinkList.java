package erichto.leet;


class LinkedListNode{
	
	int val;
	LinkedListNode next;
	public int getVal() {
		return val;
	}
	public void setVal(int val) {
		this.val = val;
	}
	public LinkedListNode getNext() {
		return next;
	}
	public void setNext(LinkedListNode next) {
		this.next = next;
	}
	public LinkedListNode(int val, LinkedListNode next) {
		super();
		this.val = val;
		this.next = next;
	}
	 
}

public class MiddleLinkList {
	
	public static void main(String[] args) {
		
 
		LinkedListNode head = new LinkedListNode(1, null);

		head.setNext(new LinkedListNode(2, new LinkedListNode(3, new LinkedListNode(4, null))));
		
		LinkedListNode tortoise=head;
		LinkedListNode hare=head;
		while(hare.next!=null) {
			
			tortoise=tortoise.next;
			hare=hare.next;
			if(hare.next!=null)
				hare=hare.next;
			
			
		}
		
		LinkedListNode temp = tortoise;
		while(temp!=null) {
			
			System.out.println(temp.val);
			temp=temp.next;
		}
				
	}

}

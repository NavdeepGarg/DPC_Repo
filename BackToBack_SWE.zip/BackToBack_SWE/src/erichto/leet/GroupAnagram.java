package erichto.leet;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

public class GroupAnagram {

	
	
	public static void main(String[] args) {
		
		ArrayList<String> strList = new ArrayList<>();
		strList.add("eat");strList.add("ate");strList.add("tan");strList.add("ant");strList.add("tea");strList.add("bat");
		Map<String,List<String>> map = new HashMap<>();
		
		for(String a : strList) {
			
			char[] charArray = a.toCharArray();
			Arrays.sort(charArray);
			String sortedString = new String(charArray);
			if(map.containsKey(sortedString)) {
				map.getOrDefault(sortedString, new ArrayList<String>()).add(a);
				
			}else {
				List<String> ls= new ArrayList<>();
				ls.add(a);
				map.put(sortedString, ls);
			}
			
		}
		
		for(Entry<String, List<String>> e : map.entrySet()) {
			System.out.println(e.getValue());
			
		}
	}
}

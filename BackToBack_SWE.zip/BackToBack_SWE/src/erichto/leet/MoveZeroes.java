package erichto.leet;

public class MoveZeroes {
	
	
	public static void main(String[] args) {
		int[] nums= {0,1,0,3,12};
		int nonzero=-1;
		for(int i =0 ; i < nums.length;i++) {
			
			if(nums[i]==0) {
				continue;
			}
			else {
				
				nums[++nonzero]=nums[i];
				
			}
			
		}
		
		for(int y=nonzero+1; y <nums.length;y++) {
			nums[y]=0;
		}
		
		for(int x: nums) {
			System.out.print(x+",");
		}
	}

}

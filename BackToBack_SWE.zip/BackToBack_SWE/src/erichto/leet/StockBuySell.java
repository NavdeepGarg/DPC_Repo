package erichto.leet;

public class StockBuySell {
	
	
	public int solve(int[][] dp, int i , int j, int[] arr) {
		
			if(dp[i][j]!=-1) {
				return dp[i][j];
			}
			//i = startDay
			for(int startDay=i; startDay <  arr.length;startDay++) {
				
				for(int nextDay = j; nextDay< arr.length ;nextDay++) {
					
					int profit = arr[nextDay]- arr[startDay];
					if(profit <0) {
						continue;
					}
					
					dp[startDay][nextDay]=
							Math.max(profit, profit+solve(dp,startDay+1,nextDay+1,arr ));
				}
				
				
			}
		
			return dp[i][j];
	}
	
	
	//correct--infinite transaction possible
	public int solve2(int[] arr) {
		
		int profit=0;
		for(int i =1 ; i < arr.length;i++) {
			
			if(arr[i]>arr[i-1]) {
				profit=profit+(arr[i]-arr[i-1]);
			}
			
		}
		return profit;
		
	}
			
			
	
	
	public static void main(String[] args) {
		
		int arr[]= {7,1,5,3,6,4};
		StockBuySell obj = new StockBuySell();
		int [][]dp =new int [arr.length+1][arr.length+1];
		
		for(int i =0 ; i < dp.length;i++) {
			for(int j =0 ; j < dp.length;j++) {
				if(j==0 || i==0) {
					dp[i][j]=0;	
				}
				else {
					dp[i][j]=-1;
				}
			}
		}
		
		//System.out.println(obj.solve(dp, 1, 2, arr));
		System.out.println(obj.solve2( arr));
	}

}

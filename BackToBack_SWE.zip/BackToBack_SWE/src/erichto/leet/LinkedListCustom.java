package erichto.leet;

class Node{
	
	private int value;
	 Node next;
	public Node(int value) {
		super();
		this.value = value;
		this.next=null;
	}
	public int getValue() {
		return value;
	}
	public void setValue(int value) {
		this.value = value;
	}
	public Node getNext() {
		return next;
	}
	public void setNext(Node next) {
		this.next = next;
	}
	
	
	//
}

public class LinkedListCustom {
	
	Node head;
	
	
	public LinkedListCustom(Node head) {
		super();
		this.head = head;
	}


	//operations
	public void addNewNode(Node head,int value) {
		Node n = new Node(value);
		Node temp = head;
		while(temp.next!=null) {
			temp= temp.next;
		}
		
		//now temp.next==null means last node
		temp.next=n;
		 
		
		//confirmation
		temp=head;
		while(temp!=null) {
			System.out.println(temp.getValue());
			temp=temp.next;
		}
	}
	
	
	public void deleteNode(int value) {
		
		Node head =this.head;
		while(head!=null) {
			if(head.getNext().getValue()==value) {
				head.setNext(head.getNext().getNext());
				break;
			}
			head=head.next;
		}
		head=this.head;
		while(head!=null) {
			System.out.println(head.getValue());
			head=head.next;
		}
	}
	
	public static void main(String[] args) {
		
		Node head = new Node(1);
		Node second = new Node(2);head.next=second;
		Node third = new Node(3);second.next=third;
		 LinkedListCustom o = new LinkedListCustom(head);
		 o.addNewNode(head, 4);
		o.deleteNode(3);
	}

}

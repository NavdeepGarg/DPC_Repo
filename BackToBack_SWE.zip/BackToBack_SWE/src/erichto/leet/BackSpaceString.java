package erichto.leet;

public class BackSpaceString {
	
	
	public static void main(String[] args) {
		
		String s = "ab#c";
		String t = "ad#c";
		
		for(int i =s.length()-1 ; i >=0 ;) {

			if(s.charAt(i)=='#') {
				String temp= s.substring(0, i-1)+s.substring(i+1,s.length());
				s=temp;
				i-=2;
			}
			
			else {
				i--;
			}
		}
		
		for(int i =t.length()-1 ; i >=0 ;) {

			if(t.charAt(i)=='#') {
				String temp= t.substring(0, i-1)+t.substring(i+1,t.length());
				t=temp;
				i-=2;
			}
			
			else {
				i--;
			}
		}
		
		System.out.println(s+","+t);;
	} 
	

}

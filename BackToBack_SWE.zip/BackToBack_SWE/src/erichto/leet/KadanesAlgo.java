package erichto.leet;

public class KadanesAlgo {
	
	
	public static int maxSubArray(int[] arr) {
		
		int ans = Integer.MIN_VALUE;
		int a=0;
		for(int i=0; i < arr.length;i++) {
			a+=arr[i];
			ans = Math.max(ans, a);
			a=Math.max(a,0);
			
		}
		
		return ans;
	}
	
	
	public static int prefixSumApp(int[] arr) {
		
		int ans = Integer.MIN_VALUE;
		int msf=0;
		int[] prefixSum=new int[arr.length];
		prefixSum[0]=arr[0];
		for(int i =1 ; i < arr.length;i++) {
			prefixSum[i]=prefixSum[i-1]+arr[i];
		
		}
		for(int i=0; i < arr.length;i++) {
			ans=Math.max(ans,prefixSum[i]-msf);
			msf=Math.min(msf, prefixSum[i]);
		}
		
		return ans;
	}
	
	public static void main(String[] args) {
		
		//int[] arr= {-2,1,-3,4,-1,2,1,-5,4};
		int[] arr= {-2,1};
		//System.out.println(maxSubArray(arr));
		System.out.println(prefixSumApp(arr));
		
	}

}

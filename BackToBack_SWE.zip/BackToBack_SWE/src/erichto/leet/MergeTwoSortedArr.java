package erichto.leet;

import java.util.Arrays;

public class MergeTwoSortedArr {
	
	
	public static void swapElements(int[] arr1, int[] arr2, int i , int j ) {
		int temp = arr1[i];
		arr1[i]=arr2[j];
		arr2[j]=temp;
		boolean valueinserted=false;
		//find correct position in arr2
		for(int x=j+1; x<arr2.length;x++) {
			
			if(arr2[x] <temp) {
				arr2[x-1]=arr2[x];				
			}
			else {
				
				arr2[x-1]=temp;
				valueinserted=true;
				break;
			}
		}
		
		if(!valueinserted) {
			arr2[arr2.length-1]=temp;
		}
	}
	
	
	public static void main(String[] args) {
		
		int[] ar1={1, 5, 9, 10, 15, 20};
		int[] ar2={2, 3, 8, 13};
		
		int i =0, j=0;
		while(i<ar1.length && j<ar2.length) {
			
			//compare
			if(ar1[i] <ar2[j]) {
				i++;
				swapElements(ar1,ar2,i,j);
				i++;
			}else {
				swapElements(ar1,ar2,i,j);
				i++;
			}
			 
		}
		
		System.out.println(Arrays.toString(ar1));
		System.out.println("--");
		System.out.println(Arrays.toString(ar2));}

}

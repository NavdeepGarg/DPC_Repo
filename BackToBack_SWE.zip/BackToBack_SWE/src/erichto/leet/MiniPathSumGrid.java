package erichto.leet;

public class MiniPathSumGrid {

	public static boolean  inside(int[][] grid, int x, int y ) {

		if(x<0 || y <0 || x>=grid.length ||y>=grid[0].length) {
			return false;
		}
		return true; 


	}


	public static int calculateMinSumpath(int[][] grid){

		 
		
		return calculateMinSumpath(grid,0,0,0,2,2);


	}

	private static int calculateMinSumpath(int[][] grid, int i, int j, int sumsf,int d1, int d2) {

		System.out.println("i "+i+","+j);
		int answer=Integer.MAX_VALUE;
		int tempAns;

		if(i==d1 && j==d2) {
		 
			return sumsf+grid[d1][d2];
		}

		if(inside(grid,i,j)   ) { 

			answer=Math.min(calculateMinSumpath(grid,   i+1, j, sumsf+grid[i][j],d1,d2), calculateMinSumpath(grid,   i, j+1, sumsf+grid[i][j],d1,d2));
			 
		
		}


		return answer;
	}

	public static void main(String[] args) {

		int[][] grid= {{1,3,1},{1,5,1},{4,2,1}};
		//int[][] grid= {{1,3},{1,5}};
		System.out.println(calculateMinSumpath(grid));


	}

}

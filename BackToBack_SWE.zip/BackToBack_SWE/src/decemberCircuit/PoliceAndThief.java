package decemberCircuit;

import java.util.HashSet;
import java.util.Set;

public class PoliceAndThief {
	
	
	public static boolean inside(int i , char[] arr) {
		
		if(i <0 || i >=arr.length) {
			return false;
		}
		return true;
	}
	
	public static void countThiefCatch(char[] arr, Set<Integer> caughtTheives, int k , int i ) {
		
		
		if (i<0) {
			return ;
		}
		if(arr[i]=='T') {
			countThiefCatch(arr,caughtTheives,k,i-1);
			return;
		}
		for(int x =i+k ; x>=i-k;x-- ) {
			
			if(inside(x, arr)) {
				
				if(arr[x]=='T' && !caughtTheives.contains(x)) {
					caughtTheives.add(x); 
					 countThiefCatch(arr,caughtTheives,k,i-1);
					 return;
				} 
			}
		}
		return ;
		
	}
	
	
	
	public static void main(String[] args) {
		
		
		//char[] arr= {'P','T','P','T'};
		//char[] arr= {'P','T','T','P','T'};
		t, p , p , p
		char[] arr= {'T','T','P','P','T','P','T'};
		Set<Integer> set  = new HashSet<>();
		countThiefCatch(arr, set, 2, arr.length-1);
		System.out.println(set.size());

		
}
}
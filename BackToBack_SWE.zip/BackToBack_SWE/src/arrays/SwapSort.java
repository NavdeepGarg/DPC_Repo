//correct
package arrays;

import java.util.ArrayList;
import java.util.List;

public class SwapSort {
	
	public static void findDuplicateAdnMissing(int[] arr){
		
		
		int pos=0;
		List<Integer> dupList=new ArrayList<>();
		List<Integer> missList=new ArrayList<>();
		for(int i=0 ; i < arr.length;) {
			
			pos=arr[i]-1;
			if(pos==i)
				i++;
			else {
				if(arr[pos]==arr[i]) {
					dupList.add(arr[pos]);
					i++;
				}else {
				swap(arr,pos,i);
				continue;
				}
			}
		}
		
		//finding Missing;
		
		for(int j =0; j < arr.length;j++) {
			
			if(arr[j]!=j+1) {
				missList.add(j+1);
			}
		}
		
		
		System.out.println("dup List "+dupList);
		System.out.println("missing List "+missList);
	}
	
	
	private static void swap(int[] arr,int pos, int i) {
		 
		int temp = arr[pos];
		arr[pos]=arr[i];
		arr[i]=temp;
		
	}


	public static void main(String[] args) {
		
		int[] input= {2,3,1,5,1};
		findDuplicateAdnMissing(input);
		
	}

}

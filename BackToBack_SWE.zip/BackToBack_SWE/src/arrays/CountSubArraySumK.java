package arrays;
//I was trying without initializing the table map 
import java.util.HashMap;
import java.util.Map;

public class CountSubArraySumK {
	
	 public int countSubarrays(int[] arr, int k) {
		    // Hash Table for storing all the current Sum
		    Map<Integer, Integer> table = new HashMap<>();
		   
		    table.put(0, 1);
		    // It holds the value of current sum of array
		    int sum =0;
		     // A variable for storing the answer initialized to 0
		    int count = 0;
		    for (int i = 0; i < arr.length; i++) {
		      sum += arr[i];
		      // Case for checking if currentSum==k
		      if (table.containsKey(sum - k)) {
		        count = count+ table.get(sum - k);
		      }
		       //Check if the CurrentSum is previously encountered in the array
		      if (table.containsKey(sum)) {
		        table.put(sum, table.get(sum)+1);
		      } else {
		        table.put(sum, 1);
		      }
		    }

		    return count;
		  }
		

	 public static void main(String[] args) {
		
		 //int arr[]= {1,-1,1,-1,1};
		 int arr[]= {1,0,-1,1};
		// int arr[]= {1,1,1,-1};
		 CountSubArraySumK obj = new CountSubArraySumK();
		 System.out.println(obj.countSubarrays(arr, 0));
		 
	}
}


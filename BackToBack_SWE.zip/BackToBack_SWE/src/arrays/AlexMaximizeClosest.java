package arrays;
 
//correct
public class AlexMaximizeClosest {

	public int maxDistToClosest(int[] seats) {

		int left[]= new int[seats.length];
		int right[]= new int[seats.length];

	 
			left[0]=Integer.MAX_VALUE;
		 
 
			right[seats.length-1]=Integer.MAX_VALUE;
	 

		for(int i = 1; i < seats.length;i++) {

			if(seats[i]==1) {
				left[i]=Integer.MAX_VALUE;
				continue;
			}
			else

				if(left[i-1]==Integer.MAX_VALUE) {
					left[i]=1;
					 
				}else {
					left[i]=left[i-1]+1;
					
				}

			}

 

		for(int i = seats.length-2; i>=0;i--) {

			if(seats[i]==1) {
				right[i]=Integer.MAX_VALUE;
				continue;
			}
			else

				if(right[i+1]==Integer.MAX_VALUE) {
					right[i]=1;
					 
				}else {
					right[i]=right[i+1]+1;
					 
				}

			}


		 
		int max=Integer.MIN_VALUE;
		for(int i = 0; i < seats.length;i++) {
			
			if(right[i]<left[i]) {
				
				left[i]=right[i];
				
			}
			
			if(max<left[i] && left[i]!=Integer.MAX_VALUE) {
				max=left[i];
			}
		}
		return max; 
		
	}

	public static void main(String[] args) {
		
		int[] seats = {1,0,0,0,1,0,1};
		AlexMaximizeClosest o = new AlexMaximizeClosest();
		System.out.println(o.maxDistToClosest(seats));

	}
}

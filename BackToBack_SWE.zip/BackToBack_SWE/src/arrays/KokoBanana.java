package arrays;

import java.util.Arrays;

public class KokoBanana {
	  
	
	
	
		public int minEatingSpeed(int[] piles, int h) {
			
			
			Arrays.sort(piles);
			int ul =0;
			int spareTime= h-piles.length;
			boolean isAscending = false;
			int k =0;
			if(spareTime>=piles.length) {
				ul=1;
				isAscending=true;
				//ascending
			}
			else {
				 ul = piles[piles.length-1-spareTime];
				 //descending
			}
			
			if(isAscending) {
				//ascending from ul
				k=solveAscending(piles, ul , h);
			}
			else{
				// desceding from ul
				k=solveDescending(piles, ul ,h);
			}
			 
			 
	        return k; 
	        
	    }
		
		
		private int solveDescending(int[] piles, int ul, int h) {

			 // finding min K 
			int countHours=0;
			int lastIndex=0;
			for( int i = 0  ; i < piles.length && countHours < h; i++) {
				
				//countHours+= Math.ceil(piles[i]/ul);
				countHours+=((piles[i] + ul - 1) / ul);
				lastIndex++;
			}
			if( countHours==h) {	
				return ul;
			}
			else if(countHours<h) {
				return solveDescending( piles,  --ul,  h) 	;
			}
			else
				return solveAscending( piles,  ++ul,  h) 	; 	
			
		
		}


		private int solveAscending(int[] piles, int ul, int h) {
			 // finding min K 
			int countHours=0;
			int lastIndex=0;
			for( int i = 0  ; i < piles.length && countHours < h; i++) {
				
				//countHours+= Math.ceil(piles[i]/ul);
				countHours+=((piles[i] + ul - 1) / ul);
				lastIndex++;
			}
			if( countHours<=h) {
				return ul;
			}
			else
				return solveAscending( piles,  ++ul,  h) 	;
			
		}


	public static void main(String[] args) {
		//int [] piles= {3,6,7,11};
		int [] piles= {312884470};
		
		 KokoBanana o  = new KokoBanana();
		 //int h = 8;
		 int h = 312884469;
		 System.out.println(o.minEatingSpeed(piles, h));
 
				 
		
	}

}

package arrays;

import java.util.ArrayList;
import java.util.List;

public class ReplaceZeroForMaxContinousOnes {
	
	
	private static int countWindowSize(int []arr, int k ) {
		int window=0;
		int left=0, right=0;
		
		
		for(  right = 0 ; right < arr.length; right++) {
			
			
			if(arr[right]==1) {
				
			}
			else {
				
				if(k>0) {
					k--;
					
				}
				else {
					window= Math.max(window, right-left);
					k--;
					while(arr[left]==1) {
						left++;
					}
					left++;
				}
				
				
			}
		}
		return window;
		

	}
	
	 	
	
	public static void main(String[] args) {
		
		//int[] arr= {1,1,0,1,1,0,0,1,1,1};
		int[] arr= {1, 1, 0, 1, 1, 0, 1, 1, 1, 1, 0, 0};
		//int[] arr= {1,0,0,0,1,0,1};
		int b = 3;
	 
		
		System.out.println(countWindowSize(arr, b));
	}

}

package arrays;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class Triplets {
	
	
	
	 
	
	public static void main(String[] args) {
		
		List<Integer> x = new ArrayList<>();
		x.add(5);x.add(4);x.add(3);
		int[] primitive = x.stream()
                .mapToInt(Integer::intValue)
                .toArray();
		System.out.println(primitive[0]);
		Arrays.sort(primitive);
		System.out.println(primitive[0]);
		
	} 


}

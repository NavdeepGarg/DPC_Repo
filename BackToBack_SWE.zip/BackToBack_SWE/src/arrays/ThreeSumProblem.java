package arrays;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Hashtable;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;

import com.sun.xml.internal.bind.v2.runtime.unmarshaller.XsiNilLoader.Array;

//Given an array of n integers, return all unique triplets [a,b,c] in the array such that a + b + c = 0.

//below solution giving problem while searching in hashtable because no order can be established and ineffect duplicay is observed. 
//Thus move to Two Pointer Walk for betterment with sorted array to organize the search space
public class ThreeSumProblem {
	
	
	
	
	 public void threeSum(int[] A) {
		 
		 Hashtable<Integer, Integer> cache = new Hashtable<>(); 
		 
		 Set<List<Integer>> allThreeSums = new HashSet<>();	 
		 for ( int i =0 ; i < A.length ; i++) {
			 cache.put(A[i], i);
			 
		 }
		  
		 int target =0 ;
		 for(int i = 0 ; i < A.length ;i++) {
			 
			 target = -A[i];
			 for(int j = 0 ; j < A.length ; j++) {
				 
				 if(j==i) {
					 continue;
				 }
				 else {
					 List<Integer> temp =  twoSum(A, j, target, cache);
					 if(temp!=null) {
						 temp.add(A[i]);
						 allThreeSums.add(temp);
					 }
				 }
			 }
			 
		 }
		 System.out.println();
		    
	  }
	 
	 
	 public List<Integer> twoSum(int[] A, int startIndex, int target, 	Hashtable<Integer, Integer> cache) {
		 
		 	int firstValue = A[startIndex];
		 	List<Integer > pair = new ArrayList<Integer>();
		 	int secondValue = target - firstValue;
		 	if(cache.containsKey(secondValue)) {
		 		
		 		pair.add(firstValue);
		 		pair.add(secondValue);
		 		return pair;
		 	}
		 	else {
		 		return null;
		 	}
		    
	  }
	 
	 
	 private void listTriplets(int[] nums, int sum) {
		 
		 Arrays.sort(nums);
		 int fixedIndex = 0;
		 int twoSum =0;
		 TreeSet<String> set = new TreeSet<>();
		 for( int i = 0 ; i < nums.length; i++) {
			 
			 //
			 fixedIndex=i;
			 twoSum = sum-nums[fixedIndex];
			 
			 
			 
			 
		 }
	 }
	 
	 
	 public static void main(String[] args) {
		 
		 
		 int arr[] = {-3, -1, 1, 0, 2, 10, -2, 8};
		 ThreeSumProblem obj = new ThreeSumProblem();
		obj.threeSum(arr);
		  
		
	}

}

package arrays;


import java.util.ArrayList;
import java.util.Arrays;

//Given an array of n integers, return all unique triplets [a,b,c] in the array such that a + b + c = 0.

import java.util.HashSet;
import java.util.Hashtable;
import java.util.List;
import java.util.Set;

public class ThreeSumWithPointers {
	
 public List<List<Integer>> threeSum(int[] A) {
		 
		 Hashtable<Integer, Integer> cache = new Hashtable<>(); 
		 
		 Set<List<Integer>> allThreeSums = new HashSet<>();	
		 
		 Arrays.sort(A);
		 int temp =0;
		 for (int i =0 ; i < A.length-2 ;i++) {
			 		 
			 temp = A[i];
			 twoSum(A,i+1,-temp,allThreeSums)	;
			 
			 
		 }
			 
		 return new ArrayList<>(allThreeSums); 
 }
 
 public void twoSum(int[] A, int startIndex, int target, Set<List<Integer>> allThreeSums) {
	 
	
	 int left = startIndex;
	 int right = A.length-1;
	 
		 	 while(left< right) {
		 		 
		 		 if(A[left] +A[right]==target) {
		 			 
		 			 ArrayList<Integer> temp = new ArrayList<>();
		 			 temp.add(A[left]);temp.add(A[right]);temp.add(-target);
		 			 allThreeSums.add(temp);
		 			 left++;
		 			 right--;
		 		 }
		 		 
		 		 else if(A[left]+A[right] > target) {
		 			 
		 			 right--;
		 		 }
		 		 else {
		 			 left++;
		 		 }
		 		 
		 		 
		 		 
		 	 }
 }
 
 public static void main(String[] args) {

	 int arr[] = {-3, -1, 1, 0, 2, 10, -2, 8};
	 ThreeSumWithPointers obj = new ThreeSumWithPointers();
	 System.out.println(obj.threeSum(arr));
	  
	  
	  
	  
}
	 
	 
	 
}


 


package arrays;

import java.util.LinkedList;
import java.util.Queue;

public class TrainTurn {
	
	
	public static int totalTurns(int N,int M,int[] A)
	  {

	    //this is default OUTPUT. You can change it.
	    int result = -404;

	    //write your Logic here:
	    Queue<Integer> waitingQueue= new LinkedList<>();
	    
	    for(int i =0 ; i < A.length;i++) {
	    	
	    	waitingQueue.add(i);
	    }
	    int boardedPassenger = 0;
	    int noOfturns=0;
	    int passengers;
	    int groupsize=0;
	    int seatsLeft=M;
	    
	    while(!waitingQueue.isEmpty()) {
	    	
	    	passengers=waitingQueue.peek();
	    	groupsize=A[passengers];
	    	if(boardedPassenger>M) {
	    		
	    	}
	    	if( seatsLeft>= groupsize) {
	    		seatsLeft-=groupsize;
	    		waitingQueue.remove();
	    	}
	    	else {
	    		int temp =waitingQueue.poll();
	    		waitingQueue.add(temp);
	    		
	    	}
	    	
	    }

	      return result;
	  }

}

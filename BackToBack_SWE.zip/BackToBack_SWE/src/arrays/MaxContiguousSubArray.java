package arrays;

public class MaxContiguousSubArray {

	
	
	
	public int maxContigousSubArrya2(int[] arr) {
		
		
		int[] prefixSum = new int[arr.length];
		prefixSum[0]=arr[0];
		int maxSum=prefixSum[0];
		for(int i =1 ;i < arr.length;i++) {
			
			prefixSum[i] = Math.max(prefixSum[i-1]+arr[i], arr[i]);
			
			if(prefixSum[i] >maxSum) {
				maxSum = prefixSum[i];
			}
		}
		
		
		return maxSum;
		
		
	}
	
	
	
	public static void main(String[] args) {
		
		//int[] arr= {-2,1,-3,4,-1,2,1,-5,4};
		int[] arr= {1,-3,-5,6,10,11,101,-300,-400,501,500,3,-4,-40};		
		MaxContiguousSubArray obj = new MaxContiguousSubArray();
		 
		System.out.println(obj.maxContigousSubArrya2(arr));
		//
		
	}
}

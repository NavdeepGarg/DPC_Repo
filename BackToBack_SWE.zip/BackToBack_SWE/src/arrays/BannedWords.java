package arrays;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map.Entry;
import java.util.Set;

public class BannedWords {

	public String mostCommonWord(String paragraph, String[] banned) {

		Set<String> bannedWords = new HashSet<String>();

		for(String s: banned) {
			bannedWords.add(s);
		}
		String[] tokens = paragraph.split("[ !?',;.]+");

		HashMap<String, Integer> map = new HashMap<>();


		for(String t : tokens) {
			if(bannedWords.contains(t.toLowerCase())) {
				//do nothing
			}else

				map.put(t.toLowerCase(), map.getOrDefault(t.toLowerCase(), 0)+1);

		}

		int max=Integer.MIN_VALUE;
		String output="";
		for( Entry<String, Integer> entry :map.entrySet()) {


			if(max<=entry.getValue()) {
				output=entry.getKey();
				max=entry.getValue();
			}
		}
		return output;
	}




	public int cutOffTree(List<List<Integer>> forest) {


		int[][] directions= {{0,1},{1,0},{-1,0},{0,-1}};

		List<List<Integer>> visited= new ArrayList<List<Integer>>();
		int z = 0;
		while(z<forest.size()) {

			visited.add(new ArrayList<>());
			List<Integer> temp = new ArrayList<>();			
			for(int i = 0 ;i < forest.get(0).size();i++) {
				temp.add(0);
			}
			visited.set(z++,temp );
		}
		int countVisitedNode=0;
		int x =0, y =0;
		int min = Integer.MAX_VALUE;
		for(List<Integer> col : forest) {
			for(int i : col) {
				if(i==0) {
					countVisitedNode++;
				}
			}
		}
		min=cutOffTreeUtil(forest,visited,x,y,directions,forest.size(),forest.get(0).size(), min,countVisitedNode);
		return min<Integer.MAX_VALUE?min:-1;

	}

	public boolean isBounded(int x , int y , int rowLen, int colLen) {

		if(x<0 || y < 0 || x >= rowLen || y >=colLen) {
			return false; 

		}
		return true;
	}







	private int cutOffTreeUtil(List<List<Integer>> forest, List<List<Integer>> visited, int x, int y, int[][] directions, int rowLen, int colLen, int min, int countVisitedNode) {

		if( forest.get(x).get(y)==0) {
			//countVisitedNode+=1;
			return Integer.MAX_VALUE;

		}

		List<Integer> row= visited.get(x);
		row.set(y, 1);
		visited.set(x, row);
		countVisitedNode+=1;
		if(countVisitedNode==forest.size()*forest.get(0).size()) {
			return 0;
		}
		for(int[] temp : directions) {

			int newRow= x+temp[0];
			int newCol= y+temp[1];

			 

				if(isBounded(newRow, newCol, rowLen, colLen)
						&& forest.get(x).get(y)<forest.get(newRow).get(newCol) 
						&& visited.get(newRow).get(newCol)!=1) {
					int tempMin =cutOffTreeUtil(forest, visited, newRow, newCol, directions, rowLen, colLen,min,countVisitedNode);
					if(tempMin!=Integer.MAX_VALUE) {
						tempMin+=1;
					}
					min = Math.min(min, tempMin);
				}
			}	

			return min;
		}




		public static void main(String[] args) {
			String paragraph = "Bob hit a ball, the hit BALL flew far after it was hit.";
			String [] banned = {"hit"};
			BannedWords o = new BannedWords();
			//System.out.println(o.mostCommonWord(paragraph, banned));
			List<List<Integer>> forest= new ArrayList<List<Integer>>();
			forest.add(new ArrayList<>());forest.add(new ArrayList<>());forest.add(new ArrayList<>());
			forest.set(0, Arrays.asList(new Integer[] { 1,2,3}));
			forest.set(1, Arrays.asList(new Integer[] { 0,0,0}));
			forest.set(2, Arrays.asList(new Integer[] { 7,6,5}));
			System.out.println(o.cutOffTree(forest));
		}
	}

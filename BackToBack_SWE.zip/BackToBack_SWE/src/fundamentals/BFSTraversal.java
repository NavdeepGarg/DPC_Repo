package fundamentals;

import java.util.HashSet;
import java.util.LinkedList;
import java.util.Queue;
import java.util.Set;

class BFSGraph{
	private int V; 
	private LinkedList<Integer> adjList[];
	BFSGraph(int v) {
	    V = v;
	    adjList = new LinkedList[v];
	    for (int i = 0; i < v; ++i)
	    	adjList[i] = new LinkedList();
	  }
	
	public void addEdge(int src, int dest) {
		
		adjList[src].add(dest);
		
	}
	
	public void bfsTraversal(LinkedList<Integer> adj[], int src) { 
		
		Queue<Integer> queue = new LinkedList<>();
		Set<Integer> visited = new HashSet<>();
		
		queue.add(src);
		while(!queue.isEmpty()) {
			int temp = queue.poll();
			System.out.println("node : "+temp);  
			visited.add(temp);
			
			for(int nbrs : adj[temp]) {
				if(!visited.contains(nbrs))
				queue.add(nbrs);
			} 
		} 
	}
	
	
	public void dfsTraversal(LinkedList<Integer> adj[], int src) {
		Set<Integer> visited = new HashSet<>();
		dfsTraversalUtil(adj, src,visited);
		
	}

	private void dfsTraversalUtil(LinkedList<Integer>[] adj, int src, Set<Integer> visited) {
		 
		visited.add(src);
		for(int nbrs : adj[src]) {
			if(visited.contains(nbrs))
			dfsTraversalUtil(adj, nbrs, visited); 
		} 
	}
}

public class BFSTraversal {

}

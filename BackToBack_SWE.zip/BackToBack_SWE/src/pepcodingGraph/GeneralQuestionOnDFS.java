package pepcodingGraph;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;

import graph.PerfectFriend.Edge;

public class GeneralQuestionOnDFS {

	

		static class Pair implements Comparable<Pair>{			
			int wsf;
			String psf;

			@Override
			public int compareTo(Pair o) {

				return this.wsf-o.wsf;
			}



		}

		static class Edge{

				int src;
				int dest;
				int weight;
				public Edge(int src, int dest, int weight) {
					super();
					this.src = src;
					this.dest = dest;
					this.weight = weight;
				}
		public static void main(String[] args) {

			BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
			System.out.println("Enter no of vertex");
			try {
				int  n = Integer.parseInt(br.readLine());

				System.out.println("Enter no of edges");
				int k = Integer.parseInt(br.readLine());
				
				ArrayList<Edge>[] graph  = new ArrayList[n];
				
				//for no of vertex				 
				for(int v =0 ; v<n ;v++) {
					graph[v]=new ArrayList<Edge>();
				}
				//for no of edges
				for(int v =0 ; v<k ;v++) {
					System.out.println("Enter edges -- src , dest and wt : ");
					String[] parts=br.readLine().split(" ");
					
					int src = Integer.parseInt(parts[0]);
					int dest= Integer.parseInt(parts[1]);
					int wt = Integer.parseInt(parts[2]);
					//un-directed graph
					graph[src].add(new Edge(src, dest,wt));
					graph[dest].add(new Edge(dest,src,wt));
					
				}
				int src=0;
				System.out.println("Enter starting point ");
				src=Integer.parseInt(br.readLine());
				System.out.println("Enter destination point ");
				int dest=Integer.parseInt(br.readLine());
				boolean[] visited = new boolean[graph.length];
				String psf="";
				printAllPathFromSrctoDest(graph,src,dest,visited,psf);
				
				
			} catch (NumberFormatException | IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}


		}
		private static void printAllPathFromSrctoDest(ArrayList<Edge>[] graph, int src, int dest,boolean[] visited,String psf) {
				if(src==dest) {
					psf+=src;
					System.out.println(psf);
					return;
				}
				visited[src]=true;
				psf+=src;
				for(Edge edge: graph[src]) {
					if(!visited[edge.dest]) {
						
						printAllPathFromSrctoDest(graph, edge.dest, dest, visited, psf);
					}
					
				}
			
				visited[src]=false;
				return;
		}


	}



}

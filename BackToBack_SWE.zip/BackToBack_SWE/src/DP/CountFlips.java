package DP;

public class CountFlips {
	
	
		public int countFlip(int index, String str) {
			
			if(str==null) {
				return -1;
			}
			if(index > str.length()-1) {
				return 0;
			}
			if(str.charAt(index)=='x') {
				return countFlip(index+1, str);
			}
			else {
				return Math.min(1+countFlip(index+1,str), countFlip(index+1, str));
			}
		}
	
		
		public int countFlip2(int index, String str) { 

			
			if(str==null) {
				return -1;
			}
			if(index-1<0) {
				return 0;
			}
			if(index-1 <str.length()-1) {
				if(str.charAt(index-1)=='x') {
					return countFlip2( index-1,str);
				}
				else if(str.charAt(index)=='x' && str.charAt(index-1)=='y')  {
					
					return Math.min(1+countFlip2( index-1,str), countFlip2(index-1, str))+ 1;
				}
				else {
					return countFlip2( index-1,str);
				}
			}
			else {
				return countFlip2( index-1,str); 
			}
		}
	
	public static void main(String[] args) {
		
		//String str ="xyxxxyxyyy";
		String str ="yyxxx";
		CountFlips obj = new CountFlips();
		
		//System.out.println(obj.countFlip(0, str)); 
		System.out.println(obj.countFlip2(str.length(), str));
		
		
	} 
	

}

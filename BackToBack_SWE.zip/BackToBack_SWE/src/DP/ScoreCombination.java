package DP;
//correct
public class ScoreCombination {

	public int totalWaysToReachScore(int finalScore, int[] pointEvents) {
	   
		return totalWaysToReachScore(finalScore, pointEvents, pointEvents.length-1);
		
	  }
	
	private int totalWaysToReachScore(int finalScore, int[] pointEvents, int n) {
		int pathCount=0;
		
		if(finalScore==0 ) {
			return pathCount=1;
		}
		if(finalScore<0 ) {
			return pathCount=0;
		}
		
		if(n==0 && pointEvents[n]==finalScore) {
			return pathCount=1;
		}
		 
		//Induction
		
		if(n>=0) {
			
			if(pointEvents[n]<finalScore) {
				return pathCount=totalWaysToReachScore(finalScore-pointEvents[n],pointEvents,n)+totalWaysToReachScore(finalScore,pointEvents,n-1);
			}
			/*else if(pointEvents[n]>finalScore) {
//				return pathCount=totalWaysToReachScore(finalScore,pointEvents,n-1);
			}*/
			else
				//return pathCount=totalWaysToReachScore(finalScore-pointEvents[n],pointEvents,n-1) +totalWaysToReachScore(finalScore,pointEvents,n-1);
			return pathCount=totalWaysToReachScore(finalScore,pointEvents,n-1);		
			 
			
		}
		return 0;
	}

	public static void main(String[] args) {
		int[] arr= {2,3,7};
		//int[] arr= {2,4,5};
		int finalScore=12;
		//int finalScore=9;
		ScoreCombination obj = new ScoreCombination();
		System.out.println(obj.totalWaysToReachScore(finalScore, arr));
	}
}

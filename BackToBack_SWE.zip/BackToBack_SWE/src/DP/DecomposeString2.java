package DP;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
//working correct
public class DecomposeString2 {
	
	
	public boolean canDecompose(String[] arr, String targetString) {
		
			HashSet<Integer> skipIndexes=new HashSet<>();
			List<String> tempList=new ArrayList<>();
			
			return canDecomposeUtil(arr,targetString,skipIndexes,tempList, new StringBuilder());
			
		
		
		
	}
	
	
	private boolean canDecomposeUtil(String[] arr, String targetString, HashSet<Integer> skipIndexes,
			List<String> tempList, StringBuilder stringBuilder) {
		
		for(int i = 0 ; i < arr.length;i++) {
			
			if(skipIndexes.contains(i)) {
				continue;
			}
			 skipIndexes.add(i);
			tempList.add(arr[i]);
			stringBuilder =new StringBuilder();
			for(String s:tempList)
			{
				
			stringBuilder.append(s);
			}
			
			if(stringBuilder.toString().equals(targetString)) {
				System.out.println(stringBuilder.toString());
				return true;
			}
			
			if(!canDecomposeUtil(arr, targetString,skipIndexes, tempList, new StringBuilder()))
			{
				tempList.remove(tempList.size()-1);
				skipIndexes.remove(i);
			}
			else 
				return true;
		}
		
		return false;
	}


	public static void main(String[] args) {
		
		String arr[]= {"plsl","lhe","e","ap"};
		DecomposeString2 obj = new DecomposeString2();
		System.out.println(obj.canDecompose(arr, "apple"));
				
	}

}

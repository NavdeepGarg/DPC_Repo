//correct
package DP;

import java.util.ArrayList;
import java.util.List;

public class DecomposeString {
	
	
	public boolean canDecompose(List<String> dictionary, String s) {

	    // Set the 0 index to True since we can always decompose an empty string
	    boolean[] decomposeString = new boolean[s.length() + 1];
	    decomposeString[0] = true;

	    // We will utilize two pointers to check if substrings exist in our dictionary
	    for (int i = 1; i <= s.length(); i++) {
	      for (int j = 0; j < i; j++) {
	        if (decomposeString[j] && dictionary.contains(s.substring(j, i))) {
	          // Update our array and break, since we have verified we can decompose our string up to index i
	          decomposeString[i] = true;
	          break;
	        }
	      }
	    }

	    // Return true if we can decompose the whole string (the last index is true)
	    return decomposeString[s.length()];
	  
	}
	
	
	 	
	public static void main(String[] args) {
		
		List<String> dictionary=new ArrayList<String>();
		dictionary.add("ap");dictionary.add("pl");dictionary.add("ppp");dictionary.add("pple");
		DecomposeString obj = new DecomposeString();
		System.out.println(obj.canDecompose(dictionary, "apple"));
		
	}

}

package DP;

public class WildCardMatching {public boolean isMatch(String s, String p) {

	if(s.isEmpty() || p.isEmpty() || s==null|| p==null ) {
		return false; 

	}
	return isMatchUtil(s, p,s.length(),p.length());

}

private boolean isMatchUtil(String s, String p, int m, int n) {

	if(n==0 &&m==0 ) {
		return true; 

	}
	if(n==0   ) {
		return false; 

	}
	if(n==1 && p.charAt(n-1)=='*'){
		return true; 
	}

	if(m==0 && n>0) {
		return false;
	}

	if(p.charAt(n-1)=='*') {
		return isMatchUtil(s, p, m, n-1) ;
	}
	else if(p.charAt(n-1)=='?' || s.charAt(m-1)==p.charAt(n-1)) {
		return isMatchUtil(s, p, m-1, n-1);
	}else {
		return false;

	}


}

public static void main(String[] args) {

	WildCardMatching o =new WildCardMatching();
	System.out.println(o.isMatch("ss", "s"));

}

}

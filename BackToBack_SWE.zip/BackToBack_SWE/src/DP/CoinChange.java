package DP;


public class CoinChange {


	public int coinChangeWays(int[] coins, int amount) {

		return coinChangeWays(coins, amount,coins.length-1);

	}

	private int coinChangeWays(int[] coins, int amount, int index) {

		if(coins.length==0)
			return -1;
		if(coins.length==1 && amount!=0) {
			if(coins[0]==amount)
				return 1;

		} 
		if(index>=0) {

			if(coins[index]<amount) {
				return Math.max(1+coinChangeWays(coins, amount-coins[index],index)  , coinChangeWays(coins, amount,index-1));

			}else if (coins[index]>amount) {
				return coinChangeWays( coins, amount,index-1);
			}else {
				return 1;
			}

		}
		return 0;
	}

//memoization
	public static int coinChanges(int[] coins, int amount, int n, int [][]dp) {
		
		if(n==0) {
		return 0;
		}
		 if(dp[amount][n]!=-1) {
			 return dp[amount][n];
		 }
		
		if(amount <coins[n-1]) {
			return dp[amount][n]=coinChanges(coins, amount, n-1,dp);
		}else {
			return dp[amount][n]=Math.max(1+coinChanges(coins, amount-coins[n-1], n,dp), coinChanges(coins, amount, n-1,dp));
		}
		
		
		

	}
	public static void main(String[] args) {


		CoinChange obj = new CoinChange();
		/*		int [] coins= {1,2,3};
		int amount=10;*/
		int [] coins= {2, 5, 3, 6};
		int amount=10;
		//N = 10 and S = {2, 5, 3, 6}
		System.out.println(obj.coinChangeWays(coins, amount));
		int[][] dp = new int [amount+1][coins.length+1];
		for(int i = 0 ;i < dp.length;i++) {
			for(int j = 0; j < dp[0].length;j++) {
				if(i==0 || (j==0&&i==0)) {
					dp[i][j]=0;
				}else if( (j==0&&i!=0))
				dp[i][j]=1;
				else
					dp[i][j]=-1;	
				
			}
		}
		//System.out.println(coinChanges(coins,amount,coins.length,dp));
		coinChanges(coins,amount,coins.length,dp);
		System.out.println(dp[amount][coins.length]);

	}

}

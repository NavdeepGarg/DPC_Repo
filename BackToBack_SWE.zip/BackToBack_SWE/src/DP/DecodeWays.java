package DP;
//CORRECT
public class DecodeWays {
	
	
	public int decodeWays(String s , int index) {
		
		if(s.length()==1 || index==0) {
			
			return 1;
		}
		
		if(s.length()==0) {
			return -1;
		}
		
		if(index==1) {
			String x = s.substring(0,2);
			if(Integer.valueOf(x)>0 && Integer.valueOf(x)<27) {
				return 2; 
				
			}
			else {
				return 1; 
			
			}
		}
		
		//Induction
		return decodeWays(s, index-1)+decodeWays( s, index-2);
		
		
		
	}
	
	public static void main(String[] args) {
		
		String s = "33";
		
		DecodeWays d = new DecodeWays();
		System.out.println(d.decodeWays(s, s.length()-1));
		
	} 
	

}

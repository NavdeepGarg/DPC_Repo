package DP;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Queue;

import graph.LinkedList;

//correct
public class JumpGameIV {

	int min=Integer.MAX_VALUE;
	public int minJumps(int[] arr) { 
        
        int n = arr.length;
        if(n==1) return 0;
        
        Map<Integer,List<Integer>> map= new HashMap<>();
        int step=0;
        for(int i =0;i < n; i++){
            
            map.computeIfAbsent(arr[i],v->new ArrayList()).add(i);
             
        }
        
        Queue<Integer> q = (Queue<Integer>) new LinkedList();
        q.offer(0);
        while(!q.isEmpty()){
            
            step++;
            int size = q.size();
            for(int i =0 ; i <size ;i++ ){
                
                int j = q.poll();
                //jump to j-1
                if(j-1>=0 && map.containsKey(arr[j-1])){
                   q.offer(j-1); 
                }
                // jump tp j+1
                if(j+1<arr.length && map.containsKey(arr[j+1])){
                      if(j+1==n-1) return step;
                   q.offer(j+1); 
                }
                
                // 
                if( map.containsKey(arr[j])){
                   for(int k : map.get(arr[j])){
                       if(k!=j){
                           if(k==n-1) return step;
                            q.offer(k);                       
                       
                       }
                   } 
                    
                }
                
                
                map.remove(arr[j]);
                
                
                
            }
        }
        
        return step;
    }
	
	
	public static void main(String[] args) {
		
		int arr[]= {100,-23,-23,404,100,23,23,23,3,404};
		//int arr[]= {-12,-86,27,-61,-4}; //4
		//int arr[]= {7};
		JumpGameIV o = new JumpGameIV();
		System.out.println(o.minJumps(arr));
				
		
		
	}
}

//NOT CORRECT
package DP;

public class MaxLengthSubArray {

	 static int result =0;
	public int findLength(int[] nums1, int[] nums2) {
		//findLength(nums1,0,nums2,0,0);
		int i =findLength(nums1,nums1.length-1,nums2,nums2.length-1);
		return i;
				
		

	}

	
	
	private int findLength(int[] nums1, int firstStart, int[] nums2, int secondStart) {
		if(firstStart <0 || secondStart <0) {
			return 0;
		}
		if(nums1[firstStart]==nums2[secondStart]) {
			//return Math.max(1+findLength(nums1,firstStart-1, nums2,secondStart-1)
			//,Math.max(findLength(nums1, firstStart, nums2, secondStart-1), findLength(nums1, firstStart-1,nums2,secondStart)));
			return 1+findLength(nums1,firstStart-1, nums2,secondStart-1);
		}
		else {
			
			return Math.max(findLength(nums1, firstStart, nums2, secondStart-1), findLength(nums1, firstStart-1,nums2,secondStart));
			
		}
	}



	private int findLength(int[] nums1, int firstStart, int[] nums2, int secondStart,int length) {
		 
		if(firstStart>=nums1.length || secondStart>=nums2.length || firstStart<0 || secondStart <0)
			return 0;
		
		if(nums1[firstStart]== nums2[secondStart] ) {
			length++;
			if(length > result) {
				result =length;
			}
			//return 1+ findLength(nums1, firstStart+1, nums2, secondStart+1,++length);
			 return Math.max(1+  findLength(nums1, firstStart+1, nums2, secondStart+1,length), 
					 Math.max(findLength(nums1, firstStart, nums2, secondStart+1,0), 
					 findLength(nums1, firstStart+1, nums2, secondStart,0)));
		}
		else { 
			
			int x = Math.max(findLength(nums1, firstStart, nums2, secondStart+1,0), findLength(nums1, firstStart+1, nums2, secondStart,0));
			if(x>length) {
				return x;
			}else {
				return 0;
			}
	 
			//return Math.max(findLength(nums1, firstStart, nums2, secondStart+1,0), findLength(nums1, firstStart+1, nums2, secondStart,0));
		}
	}

	
	public static void main(String[] args) {
		
		/* int[] nums1= {1,2,3,2,1};
		int[]  nums2 = {3,2,1,4,7};*/ 
		/*  int[] nums1= {0,1,1,1,1};
		int[]  nums2 = {1,0,1,0,1};  */
		//int[] nums1= {0,0,0,0,1},nums2= {1,0,0,0,0};
		
		int[] nums1 = {1,0,0,0,1}, nums2 = {1,0,0,1,1}; //ans=3
 		  
		/*int[] nums1= {0,0,0,0,0,0,1,0,0,0};
		int[]  nums2 = {0,0,0,0,0,0,0,1,0,0}; */
		   
		MaxLengthSubArray obj = new MaxLengthSubArray();
		System.out.println(obj.findLength(nums1,nums2));
		System.out.println(result);
		
		
	}
}

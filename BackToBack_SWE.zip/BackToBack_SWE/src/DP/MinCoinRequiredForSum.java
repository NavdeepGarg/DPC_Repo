package DP;
//correct
public class MinCoinRequiredForSum {
	
	public static int minCoinRequired(int coins[], int sum) {
		
			int dp[][]= new int [coins.length+1][sum+1];
			
			for(int i =0 ;i <= sum;i++) {
				dp[0][i]=Integer.MAX_VALUE-1;
			}
			for(int i =0 ;i <= coins.length;i++) {
				dp[i][0]=0;
			}
			for(int i =1; i <=sum ;i++) {
				//row second
				if(i%coins[0]==0) {
					dp[1][i]=i/coins[0];
				}
				else {
					dp[1][i]=Integer.MAX_VALUE-1;
				}
			}
			
			for(int i =2 ; i <=coins.length;i++) {
				
				for(int j = 1; j <=sum;j++) {
					
					dp[i][j]=-1;
				}
			}
				
			
			dp[0][0]=Integer.MAX_VALUE-1;
			
			for(int i=0; i < dp.length;i++) {
				for(int j = 0;j <dp[0].length;j++) {
					System.out.print(dp[i][j]+",");
				}
				System.out.println("");
			}
			int answer= minCoinRequired(coins, sum,coins.length,dp);
			
			System.out.println("----");
			for(int i=0; i < dp.length;i++) {
				for(int j = 0;j <dp[0].length;j++) {
					System.out.print(dp[i][j]+",");
				}
				System.out.println("");
			}
			
			 if(answer>=Integer.MAX_VALUE-1)
				 answer=-1;
				
			return answer;
		 
	}
	
	
	private static int minCoinRequired(int[] coins, int sum, int n ,int[][] dp) {
		
		if(dp[n][sum]!=-1) {
			return dp[n][sum];
		}
		
		 if(coins[n-1]<=sum) {
			 
			 return dp[n][sum]=Math.min(1+minCoinRequired(coins, sum-coins[n-1],n,dp), minCoinRequired(coins, sum, n-1, dp));
			 
		 }
		 else {
			 return dp[n][sum]= minCoinRequired(coins, sum, n-1, dp);
		 }
		
	}

 
	public static void main(String[] args) {
		
		int coins[]= {1,2,3};
		 
		System.out.println("--"+minCoinRequired(coins,10));
	}

}

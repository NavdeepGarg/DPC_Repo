package DP;

public class KnapsackDP {

	

	private static  int knapSack(int W, int[] wt, int[] val, int n) {
	 
		if(n==0 || W==0) {
			//base condition-- smallest valid input
			//arr length is zero or weight is zero
			return 0;
		}
		
		
		if(wt[n-1]<=W) {
			
			return
					 Math.max(val[n-1]+knapSack(W-wt[n-1], wt, val, n-1) , 
							 knapSack(W, wt, val, n-1));
			
		}
		
		
		else {
			return knapSack(W, wt, val, n-1);
		}
		 
	}
	
	

	private static  int knapSackUsingIndex(int W, int[] wt, int[] val, int n) {
	 
		if(n<0 || W==0) {
			//base condition-- smallest valid input
			//arr length is zero or weight is zero
			return 0;
		}
		
		
		if(wt[n]<=W) {
			
			return
					 Math.max(val[n]+knapSackUsingIndex(W-wt[n], wt, val, n-1) , 
							 knapSackUsingIndex(W, wt, val, n-1));
			
		}
		
		
		else {
			return knapSackUsingIndex(W, wt, val, n-1);
		}
		 
	}
	

	private static  int knapSackUsingMemoization(int W, int[] wt, int[] val, int n, int dp[][]) {
	 
		if(n<0 || W==0) {
			//base condition-- smallest valid input
			//arr length is zero or weight is zero
			return 0;
		}
		
		if (dp[n][W] != -1)
	        return dp[n][W];  
		
		
		if(wt[n]<=W) {
			
			return dp[n][W]=
					 Math.max(val[n]+knapSackUsingMemoization(W-wt[n], wt, val, n-1,dp) , 
							 knapSackUsingMemoization(W, wt, val, n-1,dp));
			
		}
		
		
		else {
			return dp[n][W]= knapSackUsingMemoization(W, wt, val, n-1,dp);
		}
		 
	}
	
	

	
	
	public static void main(String[] args) {
		int val[] = { 60, 100, 120 };  
	    int wt[] = { 10, 20, 30 };  
	     
	    int W = 50; 
	    int N = val.length;        
	     
	    System.out.println(knapSack(W, wt, val, N));
	    System.out.println(knapSackUsingIndex(W, wt, val, N-1));
	    int dpUsingIndexes[][]= new int[N+1][W+1];
	    for(int i = 0; i < N + 1; i++)  
	        for(int j = 0; j < W + 1; j++)  
	        	dpUsingIndexes[i][j] = -1; 
	    
	    System.out.println(knapSackUsingMemoization(W, wt, val, N-1, dpUsingIndexes));
	    
	    
	    
	}

}

package DP;


//NOT CORRECT
public class MaxSumContiguousSubArray {
	
	public int maxContiguousSubarraySum(int[] arr) {
		
		if(arr.length==0) {
			return 0;
		}
		int[] t = new int[arr.length];
		for(int i =0 ; i < t.length; i++)
			t[i]=-1;
		 maxContiguousSubarraySum(arr,0,0,t) ;
		 for(int i =0 ; i < t.length; i++)
				System.out.print(t[i]+"\t");
		 return t[arr.length-1];
			
		
	}
	
	 

	private int maxContiguousSubarraySum(int[] arr, int startIndex,int sum,int[] dp) {
		 
		
		if(startIndex==arr.length-1) {
			dp[startIndex]= Math.max(sum+arr[startIndex],arr[startIndex]);
			return  dp[startIndex];
			
		}
		if(dp[startIndex]!=-1) {
			return dp[startIndex];
		}
		else {
		 dp[startIndex]= Math.max(sum,Math.max(maxContiguousSubarraySum(arr, startIndex+1, sum+arr[startIndex],dp),
				maxContiguousSubarraySum(arr, startIndex+1, 0,dp)));
		 sum=dp[startIndex];
		 return dp[startIndex];
		}
		
		
	}



	public static void main(String[] args) {
		
		int[] arr= {-2, 1, -3, 4, -1, 2, 1, -5, 4};
		
		
		MaxSumContiguousSubArray obj = new MaxSumContiguousSubArray();
		System.out.println(obj.maxContiguousSubarraySum(arr));
		
		
	}

}

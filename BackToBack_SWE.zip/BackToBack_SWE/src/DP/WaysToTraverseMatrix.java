
package DP;

public class WaysToTraverseMatrix {
	
		  public int wttm(int i , int j ) {
			  
			  
			  if(i==0 && j==0) {
				  return 1; 
				 
			  }
			  
			  int noOfWays ;
			  if(i ==0 ) {
				  
				  return wttm(i,j-1);
				  
			  }
			  if(j ==0) {
	
				  return wttm(i-1,j);
				  
			  }
			  
			  noOfWays = wttm(i-1,j)+ wttm(i,j-1);
			  
			  return noOfWays;
		  }
	
	public static void main(String[] args) {
		
		WaysToTraverseMatrix obj = new WaysToTraverseMatrix();
		int m  = 3;
		int n =3;
		int[][] matrix  = new int [m][n];	
		int x = obj.wttm(m-1, n-1);
		System.out.println(x);
		
	} 
	

}

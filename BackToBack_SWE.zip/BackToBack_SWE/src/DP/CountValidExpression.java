//correct
package DP;

public class CountValidExpression {
	
	
	public int countValidExpression(int[] num, int target) {
		
		return countValidExpression(num,target,0,num.length-1);
	}
	
	
	private int countValidExpression(int[] num, int target, int startIndex, int endIndex) {
		
		if(startIndex==endIndex) {
			if(num[startIndex]==target || -num[startIndex]==target) {
				return 1;
			}
			else {
				return 0;
			}
		}
		
		if(startIndex>endIndex)
			return 0;
		
		return countValidExpression(num, target-num[startIndex], startIndex+1, endIndex) +countValidExpression(num, target+num[startIndex], startIndex+1, endIndex);
		
		
	}


	public static void main(String[] args) {
		
		//int[] num= {1,2,1};
		int[] num= {1,2,3};
		//int target = 2;
		int target = 10;
		CountValidExpression obj = new CountValidExpression();
		int count = obj.countValidExpression(num, target);
		
		System.out.println(count);
		
	}

}

package DP;
//TOP DOWN APPROACH
public class LongestPalindromicSubSequence {
	
	
	public int longestPalindromicSubSeq(String original) {
		
		StringBuilder sb=new StringBuilder(original);
		sb.reverse();
		
		String reverse= sb.toString();
		
		return longestPalindromicSubSeq(original,original.length()-1,reverse,reverse.length()-1);
		
		
	}
	
	private int longestPalindromicSubSeq(String original,int firstIndex ,String reverse,int secondIndex) {
		 
		
		if(firstIndex <0 || secondIndex <0) {
			return 0;
		}
		
		if(original.charAt(firstIndex)== reverse.charAt(secondIndex)) {
			return 1+ longestPalindromicSubSeq(original, firstIndex-1, reverse, secondIndex-1);
		}
		
		else {
			return Math.max(longestPalindromicSubSeq(original, firstIndex, reverse, secondIndex-1)
					,longestPalindromicSubSeq(original, firstIndex-1, reverse, secondIndex));
		}
		
		
	}

	public static void main(String[] args) {
		//String s= "BBABCBCAB";
		String s= "GEEKSFORGEEKS";
		LongestPalindromicSubSequence obj = new LongestPalindromicSubSequence();
		System.out.println(obj.longestPalindromicSubSeq(s));
		
	}

}

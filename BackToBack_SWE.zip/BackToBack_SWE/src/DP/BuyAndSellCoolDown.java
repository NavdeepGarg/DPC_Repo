package DP;

//cool down happen for one day after you sell the stock
public class BuyAndSellCoolDown {
	
	
	public int maxProfit(int[] prizes, int fee) {
		
		
		
	}

	
	public int maxProfit(int[] prizes) {
		
		int len=prizes.length;
		if(len<1) {
			return 0;
		}
		if(len==2 && prizes[1] >prizes[0]) {
			return prizes[1]-prizes[0]; 
		}else if(len==2 && prizes[1] <prizes[0]) {
			return 0;
		}
		
		int[][] dp = new int[len][2];
		
		dp[0][0]=0;
		dp[0][1]=-prizes[0];
		dp[1][0]=Math.max(dp[0][1]+prizes[1], dp[0][0]);
		dp[1][1]=Math.max(dp[0][0]-prizes[1],dp[0][1]);
		for(int i = 2; i < len;i++) {
			
			dp[i][0]=Math.max(dp[i-1][0],prizes[i]+dp[i-1][1]);
			dp[i][1]=Math.max(dp[i-2][1]-prizes[i],dp[i-1][1]);
		}
		
		
		return dp[len-1][0];
	}
}

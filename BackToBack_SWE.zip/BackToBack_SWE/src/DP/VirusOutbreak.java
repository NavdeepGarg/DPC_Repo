package DP;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class VirusOutbreak {
	
	public int lcs(String V, int n , String B, int m) {
		
		if(V==null || B==null ) {
			return 0;
			
		}
		if(V.equals(B)) {
			return 1;
		}
		
		if(n<m) {
			return 0;
		}
		 
		if(m<0  ) {
			return 1;
		}
		
		if(V.charAt(n)==B.charAt(m)) {
			return lcs(V,n-1,B,m-1);
		}
		else {
			return lcs(V,n-1,B,m);
		}
		
	}
	
	
	public static void main(String[] args) {
		
		 
		VirusOutbreak obj = new VirusOutbreak() ;
		@SuppressWarnings("resource")
		Scanner sc= new Scanner(System.in);
		System.out.println("Enter V");
		String V= sc.next();
		System.out.println("Enter no of sample");
		int sample= sc.nextInt();
		List<String> inputSample = new ArrayList<>();
		List<String> output= new ArrayList<>();
		for(int i = 0 ; i < sample ; i++) {
			System.out.println("Enter sample "+ (i+1));
			inputSample.add(sc.next());
			
		}
		
		int temp=0;
		for(String B : inputSample) {
			
			
			
			temp = obj.lcs(V, V.length()-1, B, B.length()-1);
			if(temp ==0) {
				output.add("NEGATIVE");
				
			}
			else {
				output.add("POSITIVE");
			}
			
		}
		
		for(String x : output) {
			
			System.out.println(x);
		}
		 
		
	}

}

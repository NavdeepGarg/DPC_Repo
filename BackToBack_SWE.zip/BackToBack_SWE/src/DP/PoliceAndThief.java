package DP;

import org.omg.Messaging.SyncScopeHelper;

public class PoliceAndThief {
	
	
	public int catchThief(int[] arr, int k ) {
		
			int[] visited= new int[arr.length];
			for(int i = 0 ; i  <visited.length;i++) {
				
				if(arr[i]==2) {
					visited[i]=-1;
				}else {
					visited[i]=0;
				}
			}
		
			return catchThief(arr, visited,0,k,0);
		
	}
	
	private  boolean isIndexBounded(int[] arr, int index) {
		
		if(index >=0 && index <arr.length) {
			return true;
		}
		else {
			return false;
		}
		
	}

	private int catchThief(int[] arr, int[] visited, int index, int k, int count) {
	 
		if(!isIndexBounded(arr, index)) {
			return count;
		}
		if(  arr[index]==1) {
			//Thief element
			return catchThief(arr, visited,index+1,k,count);
		}
		if(  visited[index]==1) {
			//Thief visited
			return catchThief(arr, visited,index+1,k,count);
		}
		
		int tempMax = count;
		int maxIndex=index;
		int forward=0;
		int backward=0;
		while(k>0) {
			
			if(isIndexBounded(arr,index+k) && visited[index+k]==0) {
				forward = catchThief(arr, visited, index+k , k, 1+tempMax);
			}
			if(isIndexBounded(arr,index-k)&& visited[index-k]==0) {
				backward = catchThief(arr, visited, index-k , k, 1+tempMax);
			}
			
			if(  forward> tempMax) {
				tempMax=forward;
				maxIndex=index+k;
			}
			if(backward>tempMax) {
				tempMax = backward;
				maxIndex=index-k;
			}
			k--;
		}
		if(tempMax > count) {
			visited[maxIndex]=1;
		}
		
		return tempMax;
	}

	
	public static void main(String[] args) {
		int[] arr= {2,1,1,2,1};
		int k =1;
		PoliceAndThief obj  = new PoliceAndThief();
		System.out.println(obj.catchThief(arr, k));
	}
}

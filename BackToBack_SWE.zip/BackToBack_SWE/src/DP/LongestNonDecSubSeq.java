package DP;
//correct
import java.util.Arrays;

public class LongestNonDecSubSeq {
	
	public static int lnds(int nums[]) { 
			  
			  // Case when input array is empty
			  if (nums.length == 0) 
			  {
			    return 0;
			  }
			  int[] maxLength = new int[nums.length];
			  Arrays.fill(maxLength, 1);
			  
			  // By default the best answer is a length of 1
			  int maximumSoFar = 1;
			  
			  // Test every possible end index of a longest increasing subsequence
			  // i constitute to the ending index of the subsequence
			  for (int i = 1; i < nums.length; i++) 
			  {

			    // Check for all the indices before i
			    // j will constitute to the second last index of subsequence
			    for (int j = 0; j < i; j++) 
			    {
			      // If jth element can be the next element
			      // That is nums[i] >= nums[j]
			      if (nums[i] >= nums[j]) 
			      {
			        // Update the ans of index i
			        maxLength[i] = Math.max(maxLength[i], maxLength[j] + 1);
			      }
			    }
			    
			    // Update the maximum length till index i
			    maximumSoFar = Math.max(maximumSoFar, maxLength[i]);
			  }
			  return maximumSoFar;
			  
			  }
			 

		
	 
	
	
	
	
	public static void main(String[] args) {
		
		
		int[] nums= {20,30,30,20,19,90};
		//int[] nums= {20,19,18,17,16,15};
		System.out.println("---"+lnds(nums));
		
		
	}

}

package DP;
//correct
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class MinWeightPathInTriangle {
	
	
	 public int minimumPathCost(List<List<Integer>> triangle) {
		 
		 
		 int sumPath =0;
		 int minValue = Integer.MAX_VALUE;
		 int parentIndex=0;
		 int layerValue=0;
		 
		 for(List<Integer> temp : triangle){
		 	
		 	
		 	
		 	if(layerValue==0){
		 	
		 	minValue = Math.min(minValue, temp.get(parentIndex));
		 	sumPath+=minValue;
		 	layerValue++;
		 	}
		 	else{	 	
		 	minValue = Math.min(temp.get(parentIndex+1), temp.get(parentIndex));
		 	
		 	if(temp.get(parentIndex+1)< temp.get(parentIndex)){
		 	
		 	minValue =temp.get(parentIndex+1);
		 	parentIndex =parentIndex+1;
		 	
		 	
		 }else{
		 	//parentIndex = parentIndex;
		 	minValue =temp.get(parentIndex);
		 
		 }
		 
		 sumPath+=minValue;
		 }
		 
		 }
		 
		 
		 return sumPath;
		 
		    
	  }
	 
	
	public static void main(String[] args) {
	
	List<List<Integer>> input = new ArrayList<List<Integer>>();
	input.add(Arrays.asList(5));
	input.add(Arrays.asList(1,6));
	input.add(Arrays.asList(4,3,10));
	input.add(Arrays.asList(3,2,4,1));
		
	
	 MinWeightPathInTriangle obj = new MinWeightPathInTriangle();
	 System.out.println(obj.minimumPathCost(input));
}
}
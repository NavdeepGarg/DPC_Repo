package recursion;

public class Power {
	
	
	static double  power(double n , int p) {
		
		if(p==0) {
			return 1;
			
		}
		
		if(p==1) {
			return n;
		}
		
		double hp = power(n, p/2);
		double res = hp*hp;
		if(p%2==0) {
			return res;
		}else {
			return res*n;
		}
	}

	public static void main(String[] args) {
		
		System.out.println(power(2, 5));
		
	}
}

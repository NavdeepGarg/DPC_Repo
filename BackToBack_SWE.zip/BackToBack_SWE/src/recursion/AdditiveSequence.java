package recursion;
 
public class AdditiveSequence {
	
	boolean isAdditiveSequence(String str) {
		
		if(str==null || str.isEmpty()) {
			return false;
		}
		
		long firstNumber =0, secondNumber=0;
		for(int i =1 ; i< str.length();i++) {
			
			 if(!verifyNumber(str.substring(0,i))){
				continue; 
			 }
			 
			 firstNumber=Long.parseLong(str.substring(0,i));
			 for(int j =i+1; j<str.length();j++) {
				 

				 if(!verifyNumber(str.substring(i,j))){
					continue; 
				 } 
				 
				 secondNumber=Long.parseLong(str.substring(i,j)); 
				 
				 if(isValidSequence(firstNumber,secondNumber,str.substring(j))) {
					 return true;
				 }
				 else {
					 return false;
				 }
				 
			 }
			
		}
		return false;
	}
	
	
	private boolean isValidSequence(long firstNumber, long secondNumber, String substring) {
		
		if(substring.length()==0) {
			return true;
		}
		
		for(int offset=1; offset<=substring.length();offset++) {
			
		
			if(!verifyNumber(substring.substring(0, offset))) {
				continue;
			}
			
			long thirdNumber  = Integer.parseInt(substring.substring(0, offset));
			
			//subtract to avoid overflow 
			boolean numberAddUp = (thirdNumber-firstNumber==secondNumber);
			if(numberAddUp && isValidSequence(secondNumber, thirdNumber, substring.substring(offset))) {
				return true;
			}
			else {
				return false;
			}
			
		}
		
		
		
		return false;
	}


	private boolean verifyNumber(String substring) {
		 if(substring=="" || substring.charAt(0)=='0') {
			 return false;
		 }
		 
		 
		 long result =0;
		 try {
			 
			 result = Long.parseLong(substring);
			 
		 }catch (NumberFormatException e) {
			 return false;
		}
		return true;
	}


	public static void main(String[] args) {
		String str="347111829";
		AdditiveSequence obj = new AdditiveSequence();
		System.out.println(obj.isAdditiveSequence(str));
	}

}

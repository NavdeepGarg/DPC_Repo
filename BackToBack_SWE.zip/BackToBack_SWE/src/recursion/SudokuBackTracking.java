package recursion;

public class SudokuBackTracking {
	
	public void solvedSudoku(int[][] board , int x, int y ) {
		
		if(x==board.length) {
			//display board
			display(board);
			return;
		}
		int nx =0, ny =0;
		if(y==board[0].length) {
			nx=x+1;
			ny=0;
		}else {
			ny=y+1;
			nx=x;
		}
		
		if(board[x][y]!=0) {
			solvedSudoku( board ,nx,ny );
		}
		else {
			
			//board value is zero;
			for(int pv = 1; pv<=9;pv++) {
				
				if(isValid(board, x,y,pv)) {
					board[x][y]=pv;
					solvedSudoku(board, nx, ny);
					//back tracking
					board[x][y]=0;
					
				}
			}
			
			
		}
		
	}
	
	
	private boolean isValid(int[][] board, int x, int y, int pv) {
		
		for(int j=0 ;j < board[0].length;j++) {
			if(board[x][j]==pv) {
				return false;
			}
		}
		//column traversal
		for(int j=0 ;j < board.length;j++) {
			if(board[j][y]==pv) {
				return false;
			}
		}
		
		int smi = x/3 *3;
		int smj = y/3 *3;
		
		for( int i =0 ; i < 3;i++) {
			for(int j =0 ; j < 3; j++) {
				
				if(board[smi+i][smj+j]==pv) {
					return false;
				}
			}
		}
		
		
		return true;
	}


	private void display(int[][] board) {
		// TODO Auto-generated method stub
		
	}


	public static void main(String[] args) {
		
	}

}

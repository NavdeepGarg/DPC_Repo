package recursion;
//correct
public class AdditiveSequence2 {
	  public boolean isAdditiveNumber(String s) {

	    // Case when string is empty
	    if (s == null || s.isEmpty()) {
	      return false;
	    }

	    int len = s.length();

	    // This constitutes to the first  number
	    for (int firstDivider = 1; firstDivider < len; firstDivider++) {
	      long firstNumber = parse(s.substring(0, firstDivider));
	      if (firstNumber == -1) {
	        continue;
	      }
	      // This constitutes to the second number
	      for (int secondDivider = firstDivider + 1; secondDivider < len; secondDivider++) {
	        long secondNumber = parse(s.substring(firstDivider, secondDivider));
	        if (secondNumber == -1) {
	          continue;
	        }

	        // This constitutes to the third number
	        String remainingString = s.substring(secondDivider);

	        // Return true if valid
	        if (isValidSequence(firstNumber, secondNumber, remainingString)) {
	          return true;
	        }
	      }
	    }

	    return false; // search results yielded no valid sequence
	  }

	  /*
	    Given a 1st & 2nd number to start from, validates that the
	    remaining string is an additive sequence
	  */
	  boolean isValidSequence(long firstNumber, long secondNumber, String remainingString) {
	    // Base case: no more characters left to decompose
	    if (remainingString.length() == 0) {
	      return true;
	    }

	    for (int offset = 1; offset <= remainingString.length(); offset++) {
	      long thirdNumber = parse(remainingString.substring(0, offset));
	      if (thirdNumber == -1) {
	        continue;
	      }

	      // subtract to avoid overflow
	      boolean numbersAddUp = thirdNumber - firstNumber == secondNumber;
	      if (
	        numbersAddUp &&
	        isValidSequence(secondNumber, thirdNumber, remainingString.substring(offset))
	      ) {
	        return true; // bubbles up the answer
	      }
	    }

	    return false; // search path yielded no valid sequence
	  }

	  // Helper function for converting string to number
	  long parse(String s) {
	    if (!s.equals("0") && s.startsWith("0")) {
	      return -1;
	    }

	    long result = 0;
	    try {
	      result = Long.parseLong(s);
	    } catch (NumberFormatException e) {
	      return -1;
	    }

	    return result;
	  }
	  
	  
	  


		public static void main(String[] args) {
			String str="347111829";
			AdditiveSequence2 obj = new AdditiveSequence2();
			System.out.println(obj.isAdditiveNumber(str));
		}

	}

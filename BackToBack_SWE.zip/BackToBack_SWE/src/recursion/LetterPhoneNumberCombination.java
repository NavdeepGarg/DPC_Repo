package recursion;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class LetterPhoneNumberCombination {

	Map<Character,String> dict = new HashMap<>();


	public List<String> letterCombinations(String digits) {
		dict.put('2',"abc");dict.put('3',"def");dict.put('4',"ghi");
		dict.put('5',"jkl");dict.put('6',"mno");dict.put('7',"pqrs");
		dict.put('8',"tuv");dict.put('9',"wxyz");

		List<String> output= new ArrayList<String>();
		if(digits.isEmpty()|| digits==null) {
			return output;
		}
		
		letterCombinationnUtil(digits, output, 0,new StringBuilder());
		return output;

	}


	private void letterCombinationnUtil(String digits, List<String> output, int index,StringBuilder stringBuilder) {
		
				if(index>=digits.length()) {
					String temp = stringBuilder.toString();
					output.add(temp);
					return;
				}
				String s = dict.get(digits.charAt(index));
				for(int i =0 ; i < s.length();i++) {
					stringBuilder.append(s.charAt(i));
					letterCombinationnUtil(digits, output, index+1, stringBuilder);
					stringBuilder.deleteCharAt(stringBuilder.length()-1);
				}
				return;
	}


	public static void main(String[] args) {
		String s ="23";
		LetterPhoneNumberCombination o = new LetterPhoneNumberCombination()
				;
		
		System.out.println( 
		o.letterCombinations(s));
	}

}

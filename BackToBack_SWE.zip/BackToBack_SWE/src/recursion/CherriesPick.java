package recursion;

class Robo{
	int x;
	int y;
	int cherrySumCollected;
	public Robo(int x, int y) {
		super();
		this.x = x;
		this.y = y;
		this.cherrySumCollected=0;
	}

}
public class CherriesPick {

	int [][] dirMatrix= {{1,-1},{1,0},{1,1}};

	private boolean isBounded(int x , int y, int[][] grid) {

		if(x<0 || y <0 || x >=grid.length|| y >=grid[0].length)
			return false;
		return true;
	}

	public int cherryPickup(int[][] grid) {

		Robo robo1 = new Robo(0, 0);
		robo1.cherrySumCollected=grid[0][0];
		Robo robo2 = new Robo(0, grid[0].length-1);
		robo2.cherrySumCollected=grid[0][grid[0].length-1];
		int cherryCollected=0;

		
		cherryCollected=	cherryPickUpUtil(robo1,robo2,grid,cherryCollected);
		return cherryCollected;
	}

	private int cherryPickUpUtil(Robo robo1, Robo robo2, int[][] grid, int cherryCollected) {
		
		if(robo1.x==grid.length-1 && robo2.x==grid.length-1) {
			
			return cherryCollected;
		}
		
		Robo robo1prime= new Robo(robo1.x, robo1.y);
		robo1prime.cherrySumCollected=robo1.cherrySumCollected;
		Robo robo2prime=new Robo(robo2.x, robo2.y);
		robo2prime.cherrySumCollected=robo2.cherrySumCollected;
		
		for(int[] dir: dirMatrix) {
			
			if(isBounded(robo1.x+dir[0], robo1.y+dir[1], grid)){
				int newX=robo1.x+dir[0];
				int newY=robo1.y+dir[1];
			
				robo1.cherrySumCollected+=grid[newX][ newY];
				//traverse for robo2
				
				for(int[] dir2: dirMatrix) {
					if(isBounded(robo2.x+dir2[0], robo2.y+dir2[1], grid)){
						int newX1=robo2.x+dir2[0];
						int newY1=robo2.y+dir2[1];
						if(newX==newX1 && newY==newY1) {
							continue;
						}
				
						robo2.cherrySumCollected+=grid[newX1][newY1];
						
						if(cherryCollected<=robo1.cherrySumCollected+robo2.cherrySumCollected) {
							cherryCollected=robo1.cherrySumCollected+robo2.cherrySumCollected;
							robo1prime.x=newX;robo1prime.y=newY;robo1prime.cherrySumCollected=robo1.cherrySumCollected;
							robo2prime.x=newX1;robo2prime.y=newY1;robo2prime.cherrySumCollected=robo2.cherrySumCollected;
						}
						robo2.cherrySumCollected-=grid[newX1][newY1];
					}
					
				}
				
				
				robo1.cherrySumCollected-=grid[newX][ newY];
			}
			
		}
		 return cherryPickUpUtil(robo1prime, robo2prime, grid, cherryCollected); 
	}
	
	public static void main(String[] args) {
//		int[][] grid= {{3,1,1},{2,5,1},{1,5,5},{2,1,1}};
		int[][] grid={{1,0,0,0,0,0,1},{2,0,0,0,0,3,0},{2,0,9,0,0,0,0},{0,3,0,5,4,0,0},{1,0,2,3,0,0,6}};

		CherriesPick o = new CherriesPick();
		System.out.println(o.cherryPickup(grid));
				

	}

}

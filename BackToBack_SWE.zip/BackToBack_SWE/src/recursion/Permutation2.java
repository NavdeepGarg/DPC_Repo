package recursion;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class Permutation2 {

	public List<List<Integer>> permute(int[] nums) {
		
		List<List<Integer>> output = new ArrayList<List<Integer>>();
		List<Integer> partial = new ArrayList<>();
		Set<Integer> usedIndexes=new HashSet<>();
		
		permuteUtil(output,nums,partial,usedIndexes);
		return output; 
		

	}
	//1 2 3 
	
	 
	
	

	private void permuteUtil(List<List<Integer>> output, int[] nums, List<Integer> partial, Set<Integer> usedIndexes) {
		 
		
		
		
		if(partial.size()==nums.length) {
			List<Integer> temp = new ArrayList<>();
			temp.addAll(partial);
			output.add(temp);
		
			return ;
		}
		 
		for(int i =0 ; i < nums.length;i++) {
			
			if( usedIndexes.contains(i)) {
				continue;
			}
			partial.add(nums[i]);
			usedIndexes.add(i);
			permuteUtil(output, nums, partial,  usedIndexes);
			usedIndexes.remove(i);
			partial.remove(partial.size()-1);
	
			
		
		}
		
		
	}
	
	public static void main(String[] args) {
		
		int[] nums= {1,2,3};
		Permutation2 o =new Permutation2();
		System.out.println(o.permute(nums));
		
	}


}

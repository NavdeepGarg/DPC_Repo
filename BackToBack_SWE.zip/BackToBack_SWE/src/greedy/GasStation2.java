package greedy;

public class GasStation2 {
	
	
	
	 public int canCompleteCircuit(int[] gas, int[] cost) {
	        
		 
		 for(int i = 0 ; i < gas.length;i++) {
			 
			if( checkCircuit(i,gas, cost)  ) {
				
				return i;
			}
			else {
				
				
				continue;
			}
		 }
		 
		 return -1;
	    }

	private boolean checkCircuit(int sp, int[] gas, int[] cost) {
		
		int len= gas.length;
		
		int i =sp;
		int tankTotal=0;
		while(len>=0) {
			
			tankTotal+=gas[i];
			if(tankTotal >=cost[i]) {
				tankTotal-=cost[i];
				i=(i+1)%gas.length;
				
			}else {
				return false;
			}
			
			len--;
		}
		if(len==-1) {
			return true;
		}
		return false;
	}
	
	public static void main(String[] args) {
		int gas[] = {1,2,3,4,5};
		int cost[] = {3,4,5,1,2};
		GasStation2 o = new GasStation2();
		System.out.println(o.canCompleteCircuit(gas, cost));
		
		
	}

}

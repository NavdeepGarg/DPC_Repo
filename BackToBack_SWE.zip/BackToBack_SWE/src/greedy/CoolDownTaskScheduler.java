package greedy;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.PriorityQueue;
 

public class CoolDownTaskScheduler {
	
	
	 public static int leastInterval(char[] tasks, int n) { 
		 
		 HashMap<Character,Integer> mapFreq = new HashMap<>();
		 for(char c : tasks) {
			 
			 mapFreq.put(c, mapFreq.getOrDefault(c, 0)+1);
		 }
		 
		 PriorityQueue<Integer> maxHeap = new PriorityQueue<>((a,b)->b-a);
		 maxHeap.addAll(mapFreq.values());
		 
		 int cycles=0;
		 while(!maxHeap.isEmpty()) {
			 List<Integer> temp = new ArrayList<>();
			 for(int i =0 ; i < n+1;i++) {
				 //value n keeping inclusive
				 
				 
				 if(!maxHeap.isEmpty()) {
					 temp.add(maxHeap.remove());
				 }
				 
				
				 
			 }
			 //pending to process in next cycle
			 for(int i :temp) {
				 if(--i>0) {
					 maxHeap.add(i);
				 }
			 }
			 cycles+=maxHeap.isEmpty()?temp.size():n+1;
		 }
		 
		 return cycles;
	 }

}

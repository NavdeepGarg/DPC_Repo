package scalerSorting;

import java.util.ArrayList;
import java.util.List;

import org.omg.Messaging.SyncScopeHelper;

public class MergeTwoSortedArray {
	
	
	public ArrayList<Integer> solve(final List<Integer> A, final List<Integer> B) {
		
		ArrayList<Integer> mergeList= new ArrayList<>();
		
		int firstLenth=A.size(), secondLength=B.size();
		int i =0, j=0;
		while(i<firstLenth && j<secondLength) {
			if(A.get(i)>=B.get(j)) {
				
				mergeList.add(B.get(j++));
				
			}else {
				mergeList.add(A.get(i++));
			}
			
		}
		
		while(i <firstLenth) {
			mergeList.add(A.get(i++));
			
			
		}
		
		while(j<secondLength) {
			mergeList.add(B.get(j++));
			
		}
		
		
		
		
		
		return mergeList;
		
		
    }
	
	
	public static void main(String[] args) {
		List<Integer> A = new ArrayList<>();
		A.add(4);A.add(7);A.add(9);
		List<Integer> B = new ArrayList<>();
		B.add(2);B.add(11);B.add(19);
		
		MergeTwoSortedArray obj = new MergeTwoSortedArray();
		System.out.println(obj.solve(A, B));
	}

}

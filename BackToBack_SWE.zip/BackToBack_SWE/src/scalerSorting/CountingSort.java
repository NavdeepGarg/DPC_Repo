package scalerSorting;

//Couting sort is a stable sort, means the order will preserved for equal values.

public class CountingSort {
	
	
	public void countSort(int[] arr , int max, int min) {
		
		int range = max-min+1;
		int[] freqArr= new int[range];
		int mapIndex;
		for(int i =0 ; i < arr.length;i++) {
			
			mapIndex=arr[i]-min;
			freqArr[mapIndex]++;
			
			
		}
		//converting to prefix sum array;
		
		for(int i =1 ; i < freqArr.length;i++) {
			//in effect it will store the ideal last position of element in sorted array
			freqArr[i]=freqArr[i]+freqArr[i-1];
		}
		int temp=0;
		
		int[] ans= new int[arr.length];	
		//making stable algorithm
		for(int i = arr.length-1;i>=0;i--) {
			temp=arr[i];
			mapIndex=temp-min;
			//index = position-1			
			ans[--freqArr[mapIndex]]=temp;
			
		}
		
		for(int i =0 ; i <arr.length;i++) {
			arr[i]=ans[i];
		}
		
		for(int i =0 ; i <arr.length;i++) {
			System.out.println(arr[i]);
		}
	}
	
	
	public static void main(String[] args) {
		int[] arr= {9,6,3,5,3,4,3,9,6,4,6,5,8,9,9};
		CountingSort obj = new CountingSort();
		obj.countSort(arr, 9, 3);
	}

}

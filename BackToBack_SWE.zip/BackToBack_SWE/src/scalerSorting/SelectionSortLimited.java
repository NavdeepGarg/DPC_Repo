package scalerSorting;

import java.util.ArrayList;
import java.util.List;

public class SelectionSortLimited {
	
	
	 public int kthsmallest(final List<Integer> A, int B) {
		 
		 int len = A.size();
		 int[] C=A.stream().mapToInt(i->i).toArray();
		 
		 int minIndex=0;
		 for( int i =0 ; i < B;i++) {
			 minIndex = i;
			 for(int j = i+1; j<len ;j++) {
				 if(C[j]< C[minIndex]) {
					 
					 minIndex = j;
				 }
				 
			 }
			  int temp=C[i];
			  C[i]=C[minIndex];
			  C[minIndex]=temp;
		 }
		 /*for(int k : C) {
			 System.out.println(k);
		 }
		 System.out.println("----------");		*/
		return C[B-1];
     }	
	
	 
public int kthsmallest( int[] A, int B) {
		 
		 int len = A.length;
		 
		 int minIndex=0;
		 for( int i =0 ; i < B;i++) {
			 minIndex = i;
			 for(int j = i+1; j<len ;j++) {
				 if(A[j]< A[minIndex]) {
					 
					 minIndex = j;
				 }
				 
			 }
			  int temp=A[i];
			  A[i]=A[minIndex];
			  A[minIndex]=temp;
		 }
		 for(int k : A) {
			 System.out.println(k);
		 }
		System.out.println("----------");
		return A[minIndex];
     }	
	
	 
	public static void main(String[] args) {
		
		List<Integer> list = new ArrayList<Integer>();
		SelectionSortLimited obj = new SelectionSortLimited();
		//int [] A = { 94, 87, 100, 11, 23, 98, 17, 35, 43, 66, 34, 53, 72, 80, 5, 34, 64, 71, 9, 16, 41, 66, 96 };
		
		int [] A= { 8, 16, 80, 55, 32, 8, 38, 40, 65, 18, 15, 45, 50, 38, 54, 52, 23, 74, 81, 42, 28, 16, 66, 35, 91, 36, 44, 9, 85, 58, 59, 49, 75, 20, 87, 60, 17, 11, 39, 62, 20, 17, 46, 26, 81, 92 };
		//list.add(2);list.add(1);list.add(4);list.add(3);list.add(2);
		for(int x: A) {
			list.add(x);

		}
		
		//obj.kthsmallest(list, 3);
		//list.add(1);
		//System.out.println(obj.kthsmallest(A, 19));
		System.out.println(obj.kthsmallest(list, 9));
		
		
	}

}

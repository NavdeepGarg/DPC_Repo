package scalerSorting;

public class RadixSort {


	public void radixSort(int[] arr) {

		int max= Integer.MIN_VALUE;
		for(int i =0 ; i < arr.length;i++) {
			if(max<arr[i]) {
				max=arr[i];
			}
		}

		int exp =1;
		//exp=1 for unit place, 10 for tens place and so on.
		while(exp<max) {

				countSortForRadix(arr, exp);
				exp=exp*10;
		}

		for(int i =0 ; i <arr.length;i++) {
			System.out.print(arr[i]+",");
		}
	}


	public void countSortForRadix(int[] arr ,int exp) {	 


		int[] freqArr= new int[10];
		int mapIndex;
		for(int i =0 ; i < arr.length;i++) {

			mapIndex=arr[i];
			freqArr[(mapIndex/exp)%10]++;


		}
		//converting to prefix sum array;

		for(int i =1 ; i < freqArr.length;i++) {
			//in effect it will store the ideal last position (not index) of element in sorted array
			freqArr[i]=freqArr[i]+freqArr[i-1];
		}
		int temp=0;

		int[] ans= new int[arr.length];	
		//making stable algorithm
		for(int i = arr.length-1;i>=0;i--) {
			temp=arr[i];
			mapIndex=temp;
			//index = position-1			
			ans[--freqArr[(mapIndex/exp)%10]]=temp;

		}

		for(int i =0 ; i <arr.length;i++) {
			arr[i]=ans[i];
		}

		 
	}
	
	
	public static void main(String[] args) {
		int[] arr= {9,6,3,5,3,4,3,9,6,4,6,5,8,9,9};
		RadixSort obj = new RadixSort();
		obj.radixSort(arr);

	}
}

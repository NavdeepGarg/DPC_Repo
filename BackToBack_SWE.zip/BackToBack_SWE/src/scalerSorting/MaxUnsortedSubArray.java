package scalerSorting;

//Prob. Stmt
//Given an array A of non-negative integers of size N. Find the minimum sub-array Al, Al+1 ,..., Ar
//such that if we sort(in ascending order) that sub-array, then the whole array should get sorted. If A is already sorted, output -1.

public class MaxUnsortedSubArray {


	public int[] subUnsort(int[] A) {

		int[] output=new int[2];
		int left=0,right=0;
		for(int i =0 ; i <A.length-1;i++) {

			if(A[i] >A[i+1]) {
				left=i;
				break;
			}

		}

		for(int i =A.length-1 ; i >0;i--) {

			if(A[i] <A[i-1]) {
				right=i;
				break;
			}

		}

		if(left==0 && right==0) {
			output[0]=-1;
			output[1]=-1;
			 
		}else {
		output[0]=left;output[1]=right;
		}
		System.out.println(left+","+right);
		return output;
	}

	public static void main(String[] args) {
		
		MaxUnsortedSubArray o = new MaxUnsortedSubArray();
		//int[] A= {1, 3, 2, 4, 5};
		int[] A= {1, 2,3};
		o.subUnsort(A);
		
	}

}

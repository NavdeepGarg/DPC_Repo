package scalerSorting;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections; 

public class WaveArray {

	
	
	  public ArrayList<Integer> wave(ArrayList<Integer> A) {
		  
			 int len = A.size();
			 Collections.sort(A);
			 int[] C=A.stream().mapToInt(i->i).toArray();
			 int temp;
			// mergeSort(C,0,len);
			 
			 for(int i=1; i < len; ) {
				 
				 temp = C[i];
				 C[i]=C[i-1];				 
				 C[i-1]=temp;
				 i+=2;
			 }
			 
			 ArrayList<Integer> output = new ArrayList<>();
			 for(int x : C) {
				 output.add(x);
			 }
			 
			 return  output;
			 
			 
	    }
	  
	 
 

	public static void main(String[] args) {
		
		ArrayList<Integer> list = new ArrayList<Integer>();
		//int [] A= {1, 2, 3, 4};
		int[] A= {5, 1, 3, 2, 4};
		//2 1 4 3 5 
		
		for(int x: A) {
			list.add(x);

		}

		WaveArray o = new WaveArray();
		System.out.println(o.wave(list));
				
		
		
	}
	
}
